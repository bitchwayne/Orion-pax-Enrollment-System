<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$department_id = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
if ($department_id <= 0) {
    echo json_encode([]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, course_name, course_code FROM courses WHERE department_id = ? AND is_active = 1 ORDER BY course_name");
$stmt->execute([$department_id]);
echo json_encode($stmt->fetchAll());
