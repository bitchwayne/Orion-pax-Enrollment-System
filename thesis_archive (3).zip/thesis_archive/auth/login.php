<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

if (isLoggedIn()) {
    redirectByRole();
}

$error = '';
if (isset($_GET['error'])) {
    if ($_GET['error'] === 'login_required') $error = 'Please log in to continue.';
    if ($_GET['error'] === 'unauthorized') $error = 'You are not authorized to access that page.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Email and password are required.';
    } else {
        $stmt = $pdo->prepare("SELECT id, name, email, password, role, department_id, course_id, is_active FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && $user['is_active'] && password_verify($password, $user['password'])) {
            $_SESSION['user_id']        = $user['id'];
            $_SESSION['user_name']      = $user['name'];
            $_SESSION['user_email']     = $user['email'];
            $_SESSION['user_role']      = $user['role'];
            $_SESSION['department_id']  = $user['department_id'];
            $_SESSION['course_id']      = $user['course_id'];

            logActivity($pdo, $user['id'], 'login', 'User logged in');
            redirectByRole();
        } else {
            $error = 'Invalid email or password, or account is inactive.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Thesis Archive – Ramon Magsaysay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/thesis_archive/assets/css/style.css">
</head>
<body class="campus-bg d-flex align-items-center justify-content-center">
    <div class="auth-card">
        <div class="text-center mb-4">
            <i class="bi bi-shield-lock text-primary" style="font-size: 2.5rem;"></i>
            <h2 class="h4 fw-bold mt-2 mb-0">Sign In</h2>
            <p class="text-muted small">Thesis &amp; Research Archive</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['registered'])): ?>
            <div class="alert alert-success py-2">Registration successful! Please log in.</div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required autofocus
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2">
                <i class="bi bi-box-arrow-in-right me-1"></i> Login
            </button>
        </form>
        <p class="text-center small mt-3 mb-0">
            New student? <a href="register.php">Create an account</a>
        </p>
        <p class="text-center small mt-1">
            <a href="/thesis_archive/">← Back to home</a>
        </p>
    </div>
</body>
</html>
