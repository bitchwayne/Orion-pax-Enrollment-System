<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

if (isLoggedIn()) {
    redirectByRole();
}

$departments = $pdo->query("SELECT id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name")->fetchAll();
$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name         = trim($_POST['name'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $password     = $_POST['password'] ?? '';
    $confirm      = $_POST['confirm_password'] ?? '';
    $student_id   = trim($_POST['student_id'] ?? '');
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $course_id    = !empty($_POST['course_id']) ? (int)$_POST['course_id'] : null;

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Name, email and password are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, student_id, department_id, course_id) VALUES (?, ?, ?, 'student', ?, ?, ?)");
            $stmt->execute([$name, $email, $hash, $student_id ?: null, $department_id, $course_id]);
            $newId = (int)$pdo->lastInsertId();
            logActivity($pdo, $newId, 'register', 'Student account created');
            header('Location: login.php?registered=1');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Thesis Archive – Ramon Magsaysay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/thesis_archive/assets/css/style.css">
</head>
<body class="campus-bg d-flex align-items-center justify-content-center py-5">
    <div class="auth-card" style="max-width: 520px;">
        <div class="text-center mb-4">
            <i class="bi bi-person-plus text-primary" style="font-size: 2.5rem;"></i>
            <h2 class="h4 fw-bold mt-2 mb-0">Student Registration</h2>
            <p class="text-muted small">Create your archive account</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" required
                       value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" name="email" class="form-control" required
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Password <span class="text-danger">*</span></label>
                    <input type="password" name="password" class="form-control" required minlength="6">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                    <input type="password" name="confirm_password" class="form-control" required minlength="6">
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Student ID (optional)</label>
                <input type="text" name="student_id" class="form-control"
                       value="<?= htmlspecialchars($_POST['student_id'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Department</label>
                <select name="department_id" id="department_id" class="form-select"
                        onchange="loadCourses(this.value, 'course_id')">
                    <option value="">Select Department</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= $d['id'] ?>" <?= (($_POST['department_id'] ?? '') == $d['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($d['department_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Course</label>
                <select name="course_id" id="course_id" class="form-select">
                    <option value="">Select Course</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2">
                <i class="bi bi-check-circle me-1"></i> Register
            </button>
        </form>
        <p class="text-center small mt-3 mb-0">
            Already have an account? <a href="login.php">Login</a>
        </p>
    </div>
    <script src="/thesis_archive/assets/js/app.js"></script>
</body>
</html>
