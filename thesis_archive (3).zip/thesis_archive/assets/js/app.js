// Thesis Archive – small helpers
document.addEventListener('DOMContentLoaded', function () {
    // Auto-dismiss alerts after 5s
    document.querySelectorAll('.alert-dismissible').forEach(function (el) {
        setTimeout(function () {
            var bsAlert = bootstrap.Alert.getOrCreateInstance(el);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });

    // Confirm delete buttons
    document.querySelectorAll('[data-confirm]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!confirm(btn.getAttribute('data-confirm') || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });
});

/**
 * Load courses by department (used in registration & forms)
 */
function loadCourses(departmentId, selectId) {
    var select = document.getElementById(selectId);
    if (!select) return;
    select.innerHTML = '<option value="">Loading...</option>';
    if (!departmentId) {
        select.innerHTML = '<option value="">Select Course</option>';
        return;
    }
    fetch('/thesis_archive/auth/get_courses.php?department_id=' + encodeURIComponent(departmentId))
        .then(function (r) { return r.json(); })
        .then(function (data) {
            select.innerHTML = '<option value="">Select Course</option>';
            data.forEach(function (c) {
                var opt = document.createElement('option');
                opt.value = c.id;
                opt.textContent = c.course_name + (c.course_code ? ' (' + c.course_code + ')' : '');
                select.appendChild(opt);
            });
        })
        .catch(function () {
            select.innerHTML = '<option value="">Error loading courses</option>';
        });
}
