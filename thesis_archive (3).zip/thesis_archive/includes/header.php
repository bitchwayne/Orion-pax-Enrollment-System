<?php
if (!isset($pageTitle)) $pageTitle = 'Thesis & Research Archive';
$user = currentUser();
$role = $user['role'] ?? '';
$base = '/thesis_archive';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> | Ramon Magsaysay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= $base ?>/assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<?= $base ?>/">
            <i class="bi bi-journal-richtext me-2"></i>RM Thesis Archive
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <?php if ($user): ?>
            <ul class="navbar-nav me-auto">
                <?php if ($role === 'admin'): ?>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/admin/dashboard.php"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/admin/research/index.php"><i class="bi bi-file-earmark-text me-1"></i>Research</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/admin/users.php"><i class="bi bi-people me-1"></i>Users</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/admin/departments.php"><i class="bi bi-building me-1"></i>Departments</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/admin/courses.php"><i class="bi bi-mortarboard me-1"></i>Courses</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/admin/logs.php"><i class="bi bi-clock-history me-1"></i>Logs</a></li>
                <?php elseif ($role === 'dean'): ?>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/dean/dashboard.php"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/dean/research/index.php"><i class="bi bi-file-earmark-text me-1"></i>Department Research</a></li>
                <?php elseif ($role === 'faculty'): ?>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/faculty/dashboard.php"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/faculty/research/index.php"><i class="bi bi-file-earmark-text me-1"></i>Research</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/faculty/research/add.php"><i class="bi bi-plus-circle me-1"></i>Upload</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/student/dashboard.php"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>/student/research/index.php"><i class="bi bi-search me-1"></i>Browse Research</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i>
                        <?= htmlspecialchars($user['name']) ?>
                        <span class="badge bg-light text-primary ms-1 text-uppercase"><?= htmlspecialchars($role) ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text small text-muted"><?= htmlspecialchars($user['email']) ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?= $base ?>/auth/logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a></li>
                    </ul>
                </li>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</nav>
<main class="container-fluid py-4 px-3 px-md-4">
<?php if (!empty($_SESSION['flash_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['flash_success']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>
<?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['flash_error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['flash_error']); ?>
<?php endif; ?>
