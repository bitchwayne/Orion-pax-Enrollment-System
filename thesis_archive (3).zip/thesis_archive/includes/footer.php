</main>
<footer class="bg-dark text-white-50 py-3 mt-auto">
    <div class="container text-center small">
        &copy; <?= date('Y') ?> Ramon Magsaysay &mdash; Thesis &amp; Research Archive System
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/thesis_archive/assets/js/app.js"></script>
</body>
</html>
