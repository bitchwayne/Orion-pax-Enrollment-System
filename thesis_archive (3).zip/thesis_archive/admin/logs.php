<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin(['admin']);

$pageTitle = 'Activity Logs';

$logs = $pdo->query("
    SELECT al.*, u.name AS user_name, u.email AS user_email
    FROM activity_logs al
    LEFT JOIN users u ON u.id = al.user_id
    ORDER BY al.created_at DESC
    LIMIT 200
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <h1>Activity Logs</h1>
    <p class="text-muted mb-0">Latest 200 system events</p>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Date / Time</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Description</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No logs yet.</td></tr>
                <?php else: foreach ($logs as $log): ?>
                    <tr>
                        <td class="small text-nowrap"><?= date('M d, Y H:i:s', strtotime($log['created_at'])) ?></td>
                        <td>
                            <?= htmlspecialchars($log['user_name'] ?? 'System') ?>
                            <?php if ($log['user_email']): ?>
                                <div class="small text-muted"><?= htmlspecialchars($log['user_email']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge bg-secondary"><?= htmlspecialchars($log['action']) ?></span></td>
                        <td class="small"><?= htmlspecialchars($log['description'] ?? '') ?></td>
                        <td class="small text-muted"><?= htmlspecialchars($log['ip_address'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
