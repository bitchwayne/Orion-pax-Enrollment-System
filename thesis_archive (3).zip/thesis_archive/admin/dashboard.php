<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin(['admin']);

$pageTitle = 'Admin Dashboard';

$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalResearch = $pdo->query("SELECT COUNT(*) FROM thesis_research")->fetchColumn();
$pending = $pdo->query("SELECT COUNT(*) FROM thesis_research WHERE status = 'pending'")->fetchColumn();
$approved = $pdo->query("SELECT COUNT(*) FROM thesis_research WHERE status = 'approved'")->fetchColumn();
$depts = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
$courses = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();

$recent = $pdo->query("
    SELECT tr.id, tr.title, tr.status, tr.created_at, u.name AS uploader
    FROM thesis_research tr
    LEFT JOIN users u ON u.id = tr.uploaded_by
    ORDER BY tr.created_at DESC LIMIT 8
")->fetchAll();

$recentLogs = $pdo->query("
    SELECT al.*, u.name AS user_name
    FROM activity_logs al
    LEFT JOIN users u ON u.id = al.user_id
    ORDER BY al.created_at DESC LIMIT 8
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <div>
        <h1>Admin Dashboard</h1>
        <p class="text-muted mb-0">Welcome, <?= htmlspecialchars(currentUser()['name']) ?></p>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="bi bi-people"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$totalUsers ?></div>
                    <div class="small text-muted">Users</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="bi bi-file-earmark-text"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$totalResearch ?></div>
                    <div class="small text-muted">Research</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="bi bi-hourglass-split"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$pending ?></div>
                    <div class="small text-muted">Pending</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-info bg-opacity-10 text-info"><i class="bi bi-check-circle"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$approved ?></div>
                    <div class="small text-muted">Approved</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-secondary bg-opacity-10 text-secondary"><i class="bi bi-building"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$depts ?></div>
                    <div class="small text-muted">Departments</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-dark bg-opacity-10 text-dark"><i class="bi bi-mortarboard"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$courses ?></div>
                    <div class="small text-muted">Courses</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card table-card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <strong>Recent Research</strong>
                <a href="research/index.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Uploader</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No research records yet.</td></tr>
                        <?php else: foreach ($recent as $r): ?>
                            <tr>
                                <td>
                                    <a href="research/view.php?id=<?= $r['id'] ?>" class="text-decoration-none">
                                        <?= htmlspecialchars(mb_strimwidth($r['title'], 0, 45, '…')) ?>
                                    </a>
                                </td>
                                <td><?= htmlspecialchars($r['uploader'] ?? '—') ?></td>
                                <td><span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                                <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card table-card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <strong>Recent Activity</strong>
                <a href="logs.php" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>
            <div class="list-group list-group-flush">
                <?php if (empty($recentLogs)): ?>
                    <div class="list-group-item text-muted text-center py-4">No activity yet.</div>
                <?php else: foreach ($recentLogs as $log): ?>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between">
                            <strong class="small"><?= htmlspecialchars($log['action']) ?></strong>
                            <span class="small text-muted"><?= date('M d H:i', strtotime($log['created_at'])) ?></span>
                        </div>
                        <div class="small text-muted"><?= htmlspecialchars($log['user_name'] ?? 'System') ?> — <?= htmlspecialchars(mb_strimwidth($log['description'] ?? '', 0, 60, '…')) ?></div>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
