<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['admin']);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("
    SELECT tr.*, d.department_name, c.course_name, u.name AS uploader_name, a.name AS approver_name
    FROM thesis_research tr
    LEFT JOIN departments d ON d.id = tr.department_id
    LEFT JOIN courses c ON c.id = tr.course_id
    LEFT JOIN users u ON u.id = tr.uploaded_by
    LEFT JOIN users a ON a.id = tr.approved_by
    WHERE tr.id = ?
");
$stmt->execute([$id]);
$r = $stmt->fetch();
if (!$r) {
    $_SESSION['flash_error'] = 'Research not found.';
    header('Location: index.php');
    exit;
}

$authors = $pdo->prepare("SELECT a.author_name FROM thesis_authors ta JOIN authors a ON a.id = ta.author_id WHERE ta.thesis_id = ?");
$authors->execute([$id]);
$authorList = array_column($authors->fetchAll(), 'author_name');

$keywords = $pdo->prepare("SELECT k.keyword FROM thesis_keywords tk JOIN keywords k ON k.id = tk.keyword_id WHERE tk.thesis_id = ?");
$keywords->execute([$id]);
$keywordList = array_column($keywords->fetchAll(), 'keyword');

$pageTitle = 'View Research';
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-start gap-2">
    <div>
        <h1 class="mb-1"><?= htmlspecialchars($r['title']) ?></h1>
        <div class="d-flex flex-wrap gap-2">
            <span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span>
            <span class="badge badge-access-<?= $r['access_type'] ?>"><?= ucfirst($r['access_type']) ?></span>
            <?php if ($r['publication_year']): ?>
                <span class="badge bg-secondary"><?= $r['publication_year'] ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="d-flex gap-2">
        <a href="edit.php?id=<?= $id ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil me-1"></i>Edit</a>
        <a href="index.php" class="btn btn-outline-secondary btn-sm">Back</a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card table-card mb-3">
            <div class="card-header bg-white"><strong>Abstract</strong></div>
            <div class="card-body">
                <?= $r['abstract'] ? nl2br(htmlspecialchars($r['abstract'])) : '<span class="text-muted">No abstract provided.</span>' ?>
            </div>
        </div>
        <?php if ($r['document_path']): ?>
        <div class="card table-card">
            <div class="card-header bg-white"><strong>Document</strong></div>
            <div class="card-body d-flex align-items-center gap-3">
                <i class="bi bi-file-earmark-pdf text-danger" style="font-size:2rem;"></i>
                <div>
                    <div><?= htmlspecialchars($r['original_filename'] ?? basename($r['document_path'])) ?></div>
                    <?php if ($r['file_size']): ?>
                        <div class="small text-muted"><?= number_format($r['file_size'] / 1024, 1) ?> KB</div>
                    <?php endif; ?>
                </div>
                <a href="/thesis_archive/<?= htmlspecialchars($r['document_path']) ?>" class="btn btn-primary ms-auto" target="_blank">
                    <i class="bi bi-download me-1"></i>Download PDF
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-lg-4">
        <div class="card table-card">
            <div class="card-header bg-white"><strong>Details</strong></div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-muted">Department</span>
                    <span><?= htmlspecialchars($r['department_name'] ?? '—') ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-muted">Course</span>
                    <span><?= htmlspecialchars($r['course_name'] ?? '—') ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-muted">Adviser</span>
                    <span><?= htmlspecialchars($r['adviser_name'] ?? '—') ?></span>
                </li>
                <li class="list-group-item">
                    <div class="text-muted small mb-1">Authors</div>
                    <?= $authorList ? htmlspecialchars(implode(', ', $authorList)) : '—' ?>
                </li>
                <li class="list-group-item">
                    <div class="text-muted small mb-1">Keywords</div>
                    <?php if ($keywordList): foreach ($keywordList as $kw): ?>
                        <span class="badge bg-light text-dark border me-1"><?= htmlspecialchars($kw) ?></span>
                    <?php endforeach; else: echo '—'; endif; ?>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-muted">Uploaded by</span>
                    <span><?= htmlspecialchars($r['uploader_name'] ?? '—') ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-muted">Uploaded</span>
                    <span><?= date('M d, Y H:i', strtotime($r['created_at'])) ?></span>
                </li>
                <?php if ($r['approved_by']): ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-muted">Approved by</span>
                    <span><?= htmlspecialchars($r['approver_name'] ?? '—') ?></span>
                </li>
                <?php endif; ?>
                <?php if ($r['status'] === 'rejected' && $r['rejection_reason']): ?>
                <li class="list-group-item">
                    <div class="text-muted small mb-1">Rejection Reason</div>
                    <?= htmlspecialchars($r['rejection_reason']) ?>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
