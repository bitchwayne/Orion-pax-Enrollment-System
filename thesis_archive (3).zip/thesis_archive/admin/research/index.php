<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['admin']);

$pageTitle = 'Manage Research';

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$dept = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;

$sql = "SELECT tr.*, d.department_name, c.course_name, u.name AS uploader_name
        FROM thesis_research tr
        LEFT JOIN departments d ON d.id = tr.department_id
        LEFT JOIN courses c ON c.id = tr.course_id
        LEFT JOIN users u ON u.id = tr.uploaded_by
        WHERE 1=1";
$params = [];

if ($q !== '') {
    $sql .= " AND (tr.title LIKE ? OR tr.abstract LIKE ? OR tr.adviser_name LIKE ?)";
    $like = "%$q%";
    $params = array_merge($params, [$like, $like, $like]);
}
if ($status !== '') {
    $sql .= " AND tr.status = ?";
    $params[] = $status;
}
if ($dept > 0) {
    $sql .= " AND tr.department_id = ?";
    $params[] = $dept;
}
$sql .= " ORDER BY tr.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$departments = $pdo->query("SELECT id, department_name FROM departments ORDER BY department_name")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <h1>Research Records</h1>
    <a href="add.php" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Add Research</a>
</div>

<div class="card table-card mb-3">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Title, abstract, adviser…" value="<?= htmlspecialchars($q) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">All</option>
                    <?php foreach (['pending','approved','rejected','archived'] as $s): ?>
                        <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Department</label>
                <select name="department_id" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= $d['id'] ?>" <?= $dept === (int)$d['id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['department_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Department</th>
                    <th>Year</th>
                    <th>Status</th>
                    <th>Access</th>
                    <th>Uploaded By</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="7" class="text-center text-muted py-5">No research found.</td></tr>
                <?php else: foreach ($rows as $r): ?>
                    <tr>
                        <td>
                            <a href="view.php?id=<?= $r['id'] ?>" class="fw-semibold text-decoration-none">
                                <?= htmlspecialchars(mb_strimwidth($r['title'], 0, 50, '…')) ?>
                            </a>
                        </td>
                        <td class="small"><?= htmlspecialchars($r['department_name'] ?? '—') ?></td>
                        <td><?= $r['publication_year'] ?? '—' ?></td>
                        <td><span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                        <td><span class="badge badge-access-<?= $r['access_type'] ?>"><?= ucfirst($r['access_type']) ?></span></td>
                        <td class="small"><?= htmlspecialchars($r['uploader_name'] ?? '—') ?></td>
                        <td class="text-end text-nowrap">
                            <a href="view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-secondary" title="View"><i class="bi bi-eye"></i></a>
                            <a href="edit.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                            <a href="delete.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger" title="Delete"
                               data-confirm="Delete this research record permanently?"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
