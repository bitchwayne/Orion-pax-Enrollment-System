<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['admin']);

$pageTitle = 'Add Research';
$departments = $pdo->query("SELECT id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name")->fetchAll();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $abstract = trim($_POST['abstract'] ?? '');
    $year = !empty($_POST['publication_year']) ? (int)$_POST['publication_year'] : null;
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $course_id = !empty($_POST['course_id']) ? (int)$_POST['course_id'] : null;
    $adviser = trim($_POST['adviser_name'] ?? '');
    $access_type = in_array($_POST['access_type'] ?? '', ['public','restricted']) ? $_POST['access_type'] : 'public';
    $status = in_array($_POST['status'] ?? '', ['pending','approved','rejected','archived']) ? $_POST['status'] : 'pending';
    $authors_raw = trim($_POST['authors'] ?? '');
    $keywords_raw = trim($_POST['keywords'] ?? '');

    if ($title === '') {
        $error = 'Title is required.';
    } else {
        $document_path = null;
        $original_filename = null;
        $file_size = null;

        if (!empty($_FILES['document']['name']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['document'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if ($ext !== 'pdf') {
                $error = 'Only PDF files are allowed.';
            } elseif ($file['size'] > 10 * 1024 * 1024) {
                $error = 'File size must not exceed 10 MB.';
            } else {
                $uploadDir = __DIR__ . '/../../uploads/research/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $safeName = 'thesis_' . time() . '_' . bin2hex(random_bytes(4)) . '.pdf';
                $dest = $uploadDir . $safeName;
                if (move_uploaded_file($file['tmp_name'], $dest)) {
                    $document_path = 'uploads/research/' . $safeName;
                    $original_filename = $file['name'];
                    $file_size = $file['size'];
                } else {
                    $error = 'Failed to save uploaded file.';
                }
            }
        }

        if ($error === '') {
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare("INSERT INTO thesis_research
                    (title, abstract, publication_year, course_id, department_id, adviser_name, document_path, original_filename, file_size, access_type, status, uploaded_by, approved_by, approved_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $approved_by = ($status === 'approved') ? currentUser()['id'] : null;
                $approved_at = ($status === 'approved') ? date('Y-m-d H:i:s') : null;
                $stmt->execute([
                    $title, $abstract ?: null, $year, $course_id, $department_id, $adviser ?: null,
                    $document_path, $original_filename, $file_size, $access_type, $status,
                    currentUser()['id'], $approved_by, $approved_at
                ]);
                $thesisId = (int)$pdo->lastInsertId();

                // Authors
                if ($authors_raw !== '') {
                    $names = array_filter(array_map('trim', preg_split('/[,;]+/', $authors_raw)));
                    foreach ($names as $aname) {
                        $a = $pdo->prepare("INSERT INTO authors (author_name) VALUES (?)");
                        $a->execute([$aname]);
                        $aid = (int)$pdo->lastInsertId();
                        $pdo->prepare("INSERT INTO thesis_authors (thesis_id, author_id) VALUES (?, ?)")->execute([$thesisId, $aid]);
                    }
                }

                // Keywords
                if ($keywords_raw !== '') {
                    $kws = array_filter(array_map('trim', preg_split('/[,;]+/', $keywords_raw)));
                    foreach ($kws as $kw) {
                        $kstmt = $pdo->prepare("INSERT IGNORE INTO keywords (keyword) VALUES (?)");
                        $kstmt->execute([$kw]);
                        $kid = $pdo->query("SELECT id FROM keywords WHERE keyword = " . $pdo->quote($kw))->fetchColumn();
                        if ($kid) {
                            $pdo->prepare("INSERT IGNORE INTO thesis_keywords (thesis_id, keyword_id) VALUES (?, ?)")->execute([$thesisId, $kid]);
                        }
                    }
                }

                logActivity($pdo, currentUser()['id'], 'add_research', "Added research #$thesisId: $title");
                $pdo->commit();
                $_SESSION['flash_success'] = 'Research record added successfully.';
                header('Location: view.php?id=' . $thesisId);
                exit;
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h1>Add Research</h1>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card table-card">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Abstract</label>
                    <textarea name="abstract" class="form-control" rows="4"><?= htmlspecialchars($_POST['abstract'] ?? '') ?></textarea>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Publication Year</label>
                    <input type="number" name="publication_year" class="form-control" min="1990" max="<?= date('Y') + 1 ?>"
                           value="<?= htmlspecialchars($_POST['publication_year'] ?? date('Y')) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Department</label>
                    <select name="department_id" id="department_id" class="form-select" onchange="loadCourses(this.value, 'course_id')">
                        <option value="">Select</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= (($_POST['department_id'] ?? '') == $d['id']) ? 'selected' : '' ?>><?= htmlspecialchars($d['department_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Course</label>
                    <select name="course_id" id="course_id" class="form-select">
                        <option value="">Select</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Adviser Name</label>
                    <input type="text" name="adviser_name" class="form-control" value="<?= htmlspecialchars($_POST['adviser_name'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Access Type</label>
                    <select name="access_type" class="form-select">
                        <option value="public">Public</option>
                        <option value="restricted">Restricted</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="pending">Pending</option>
                        <option value="approved" selected>Approved</option>
                        <option value="rejected">Rejected</option>
                        <option value="archived">Archived</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Authors (comma-separated)</label>
                    <input type="text" name="authors" class="form-control" placeholder="Juan Dela Cruz, Maria Santos" value="<?= htmlspecialchars($_POST['authors'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Keywords (comma-separated)</label>
                    <input type="text" name="keywords" class="form-control" placeholder="machine learning, education" value="<?= htmlspecialchars($_POST['keywords'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">PDF Document (max 10 MB)</label>
                    <input type="file" name="document" class="form-control" accept=".pdf,application/pdf">
                </div>
                <div class="col-12 d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i> Save</button>
                    <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
