<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['admin']);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM thesis_research WHERE id = ?");
$stmt->execute([$id]);
$research = $stmt->fetch();
if (!$research) {
    $_SESSION['flash_error'] = 'Research not found.';
    header('Location: index.php');
    exit;
}

$pageTitle = 'Edit Research';
$departments = $pdo->query("SELECT id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name")->fetchAll();
$error = '';

// Existing authors & keywords
$authors = $pdo->prepare("SELECT a.author_name FROM thesis_authors ta JOIN authors a ON a.id = ta.author_id WHERE ta.thesis_id = ?");
$authors->execute([$id]);
$authorStr = implode(', ', array_column($authors->fetchAll(), 'author_name'));

$keywords = $pdo->prepare("SELECT k.keyword FROM thesis_keywords tk JOIN keywords k ON k.id = tk.keyword_id WHERE tk.thesis_id = ?");
$keywords->execute([$id]);
$keywordStr = implode(', ', array_column($keywords->fetchAll(), 'keyword'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $abstract = trim($_POST['abstract'] ?? '');
    $year = !empty($_POST['publication_year']) ? (int)$_POST['publication_year'] : null;
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $course_id = !empty($_POST['course_id']) ? (int)$_POST['course_id'] : null;
    $adviser = trim($_POST['adviser_name'] ?? '');
    $access_type = in_array($_POST['access_type'] ?? '', ['public','restricted']) ? $_POST['access_type'] : 'public';
    $status = in_array($_POST['status'] ?? '', ['pending','approved','rejected','archived']) ? $_POST['status'] : 'pending';
    $authors_raw = trim($_POST['authors'] ?? '');
    $keywords_raw = trim($_POST['keywords'] ?? '');
    $rejection_reason = trim($_POST['rejection_reason'] ?? '');

    if ($title === '') {
        $error = 'Title is required.';
    } else {
        $document_path = $research['document_path'];
        $original_filename = $research['original_filename'];
        $file_size = $research['file_size'];

        if (!empty($_FILES['document']['name']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['document'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if ($ext !== 'pdf') {
                $error = 'Only PDF files are allowed.';
            } elseif ($file['size'] > 10 * 1024 * 1024) {
                $error = 'File size must not exceed 10 MB.';
            } else {
                $uploadDir = __DIR__ . '/../../uploads/research/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $safeName = 'thesis_' . time() . '_' . bin2hex(random_bytes(4)) . '.pdf';
                $dest = $uploadDir . $safeName;
                if (move_uploaded_file($file['tmp_name'], $dest)) {
                    if ($document_path && file_exists(__DIR__ . '/../../' . $document_path)) {
                        @unlink(__DIR__ . '/../../' . $document_path);
                    }
                    $document_path = 'uploads/research/' . $safeName;
                    $original_filename = $file['name'];
                    $file_size = $file['size'];
                } else {
                    $error = 'Failed to save uploaded file.';
                }
            }
        }

        if ($error === '') {
            $pdo->beginTransaction();
            try {
                $approved_by = $research['approved_by'];
                $approved_at = $research['approved_at'];
                if ($status === 'approved' && $research['status'] !== 'approved') {
                    $approved_by = currentUser()['id'];
                    $approved_at = date('Y-m-d H:i:s');
                }

                $stmt = $pdo->prepare("UPDATE thesis_research SET
                    title=?, abstract=?, publication_year=?, course_id=?, department_id=?, adviser_name=?,
                    document_path=?, original_filename=?, file_size=?, access_type=?, status=?,
                    approved_by=?, approved_at=?, rejection_reason=?
                    WHERE id=?");
                $stmt->execute([
                    $title, $abstract ?: null, $year, $course_id, $department_id, $adviser ?: null,
                    $document_path, $original_filename, $file_size, $access_type, $status,
                    $approved_by, $approved_at, $status === 'rejected' ? $rejection_reason : null, $id
                ]);

                // Reset authors
                $pdo->prepare("DELETE FROM thesis_authors WHERE thesis_id = ?")->execute([$id]);
                if ($authors_raw !== '') {
                    $names = array_filter(array_map('trim', preg_split('/[,;]+/', $authors_raw)));
                    foreach ($names as $aname) {
                        $a = $pdo->prepare("INSERT INTO authors (author_name) VALUES (?)");
                        $a->execute([$aname]);
                        $aid = (int)$pdo->lastInsertId();
                        $pdo->prepare("INSERT INTO thesis_authors (thesis_id, author_id) VALUES (?, ?)")->execute([$id, $aid]);
                    }
                }

                // Reset keywords
                $pdo->prepare("DELETE FROM thesis_keywords WHERE thesis_id = ?")->execute([$id]);
                if ($keywords_raw !== '') {
                    $kws = array_filter(array_map('trim', preg_split('/[,;]+/', $keywords_raw)));
                    foreach ($kws as $kw) {
                        $pdo->prepare("INSERT IGNORE INTO keywords (keyword) VALUES (?)")->execute([$kw]);
                        $kid = $pdo->query("SELECT id FROM keywords WHERE keyword = " . $pdo->quote($kw))->fetchColumn();
                        if ($kid) {
                            $pdo->prepare("INSERT IGNORE INTO thesis_keywords (thesis_id, keyword_id) VALUES (?, ?)")->execute([$id, $kid]);
                        }
                    }
                }

                logActivity($pdo, currentUser()['id'], 'edit_research', "Updated research #$id: $title");
                $pdo->commit();
                $_SESSION['flash_success'] = 'Research updated successfully.';
                header('Location: view.php?id=' . $id);
                exit;
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
    // Refresh form values from POST on error
    $research = array_merge($research, $_POST);
    $authorStr = $authors_raw ?? $authorStr;
    $keywordStr = $keywords_raw ?? $keywordStr;
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h1>Edit Research</h1>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card table-card">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required value="<?= htmlspecialchars($research['title']) ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Abstract</label>
                    <textarea name="abstract" class="form-control" rows="4"><?= htmlspecialchars($research['abstract'] ?? '') ?></textarea>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Publication Year</label>
                    <input type="number" name="publication_year" class="form-control" min="1990" max="<?= date('Y') + 1 ?>"
                           value="<?= htmlspecialchars($research['publication_year'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Department</label>
                    <select name="department_id" id="department_id" class="form-select" onchange="loadCourses(this.value, 'course_id')">
                        <option value="">Select</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= (int)($research['department_id'] ?? 0) === (int)$d['id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['department_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Course</label>
                    <select name="course_id" id="course_id" class="form-select">
                        <option value="">Select</option>
                        <?php
                        if (!empty($research['department_id'])) {
                            $cs = $pdo->prepare("SELECT id, course_name, course_code FROM courses WHERE department_id = ? AND is_active = 1");
                            $cs->execute([$research['department_id']]);
                            foreach ($cs->fetchAll() as $c) {
                                $sel = (int)($research['course_id'] ?? 0) === (int)$c['id'] ? 'selected' : '';
                                echo '<option value="' . $c['id'] . '" ' . $sel . '>' . htmlspecialchars($c['course_name']) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Adviser Name</label>
                    <input type="text" name="adviser_name" class="form-control" value="<?= htmlspecialchars($research['adviser_name'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Access Type</label>
                    <select name="access_type" class="form-select">
                        <option value="public" <?= ($research['access_type'] ?? '') === 'public' ? 'selected' : '' ?>>Public</option>
                        <option value="restricted" <?= ($research['access_type'] ?? '') === 'restricted' ? 'selected' : '' ?>>Restricted</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" id="status_select">
                        <?php foreach (['pending','approved','rejected','archived'] as $s): ?>
                            <option value="<?= $s ?>" <?= ($research['status'] ?? '') === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12" id="rejection_box" style="<?= ($research['status'] ?? '') === 'rejected' ? '' : 'display:none' ?>">
                    <label class="form-label">Rejection Reason</label>
                    <textarea name="rejection_reason" class="form-control" rows="2"><?= htmlspecialchars($research['rejection_reason'] ?? '') ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Authors (comma-separated)</label>
                    <input type="text" name="authors" class="form-control" value="<?= htmlspecialchars($authorStr) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Keywords (comma-separated)</label>
                    <input type="text" name="keywords" class="form-control" value="<?= htmlspecialchars($keywordStr) ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">PDF Document (leave empty to keep current)</label>
                    <?php if ($research['document_path']): ?>
                        <div class="small text-muted mb-1">Current: <?= htmlspecialchars($research['original_filename'] ?? basename($research['document_path'])) ?></div>
                    <?php endif; ?>
                    <input type="file" name="document" class="form-control" accept=".pdf,application/pdf">
                </div>
                <div class="col-12 d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i> Update</button>
                    <a href="view.php?id=<?= $id ?>" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
document.getElementById('status_select').addEventListener('change', function() {
    document.getElementById('rejection_box').style.display = this.value === 'rejected' ? '' : 'none';
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
