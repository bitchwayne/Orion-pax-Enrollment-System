<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['admin']);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT id, title, document_path FROM thesis_research WHERE id = ?");
$stmt->execute([$id]);
$r = $stmt->fetch();

if ($r) {
    if ($r['document_path'] && file_exists(__DIR__ . '/../../' . $r['document_path'])) {
        @unlink(__DIR__ . '/../../' . $r['document_path']);
    }
    $pdo->prepare("DELETE FROM thesis_research WHERE id = ?")->execute([$id]);
    logActivity($pdo, currentUser()['id'], 'delete_research', "Deleted research #$id: " . $r['title']);
    $_SESSION['flash_success'] = 'Research deleted successfully.';
} else {
    $_SESSION['flash_error'] = 'Research not found.';
}
header('Location: index.php');
exit;
