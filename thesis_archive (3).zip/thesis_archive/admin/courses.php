<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin(['admin']);

$pageTitle = 'Courses';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $name = trim($_POST['course_name'] ?? '');
        $code = trim($_POST['course_code'] ?? '') ?: null;
        $dept = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
        if ($name === '') {
            $error = 'Course name is required.';
        } else {
            $pdo->prepare("INSERT INTO courses (course_name, course_code, department_id) VALUES (?,?,?)")
                ->execute([$name, $code, $dept]);
            logActivity($pdo, currentUser()['id'], 'add_course', "Added course: $name");
            $_SESSION['flash_success'] = 'Course added.';
            header('Location: courses.php');
            exit;
        }
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $pdo->prepare("UPDATE courses SET is_active = NOT is_active WHERE id = ?")->execute([$id]);
            $_SESSION['flash_success'] = 'Course status updated.';
        }
        header('Location: courses.php');
        exit;
    }
}

$rows = $pdo->query("
    SELECT c.*, d.department_name
    FROM courses c
    LEFT JOIN departments d ON d.id = c.department_id
    ORDER BY d.department_name, c.course_name
")->fetchAll();
$departments = $pdo->query("SELECT id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <h1>Courses</h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCourseModal"><i class="bi bi-plus-lg me-1"></i> Add Course</button>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Code</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="fw-semibold"><?= htmlspecialchars($r['course_name']) ?></td>
                    <td><?= htmlspecialchars($r['course_code'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($r['department_name'] ?? '—') ?></td>
                    <td>
                        <?php if ($r['is_active']): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-<?= $r['is_active'] ? 'warning' : 'success' ?>">
                                <?= $r['is_active'] ? 'Disable' : 'Enable' ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="addCourseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div class="modal-header">
                    <h5 class="modal-title">Add Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Course Name *</label>
                        <input type="text" name="course_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="course_code" class="form-control" placeholder="e.g. BSIT">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Department</label>
                        <select name="department_id" class="form-select">
                            <option value="">—</option>
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['department_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
