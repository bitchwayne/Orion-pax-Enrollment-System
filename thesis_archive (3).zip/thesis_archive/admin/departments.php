<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin(['admin']);

$pageTitle = 'Departments';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = trim($_POST['department_name'] ?? '');
        $code = trim($_POST['department_code'] ?? '') ?: null;
        $desc = trim($_POST['description'] ?? '') ?: null;
        if ($name === '') {
            $error = 'Department name is required.';
        } else {
            try {
                $pdo->prepare("INSERT INTO departments (department_name, department_code, description) VALUES (?,?,?)")
                    ->execute([$name, $code, $desc]);
                logActivity($pdo, currentUser()['id'], 'add_department', "Added department: $name");
                $_SESSION['flash_success'] = 'Department added.';
                header('Location: departments.php');
                exit;
            } catch (PDOException $e) {
                $error = 'Department name already exists or database error.';
            }
        }
    } elseif ($action === 'update') {
        $id   = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['department_name'] ?? '');
        $code = trim($_POST['department_code'] ?? '') ?: null;
        $desc = trim($_POST['description'] ?? '') ?: null;
        if ($id <= 0 || $name === '') {
            $error = 'Department name is required.';
        } else {
            try {
                $pdo->prepare("UPDATE departments SET department_name=?, department_code=?, description=? WHERE id=?")
                    ->execute([$name, $code, $desc, $id]);
                logActivity($pdo, currentUser()['id'], 'edit_department', "Updated department #$id: $name");
                $_SESSION['flash_success'] = 'Department updated.';
                header('Location: departments.php');
                exit;
            } catch (PDOException $e) {
                $error = 'Could not update. Name may already exist.';
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare("UPDATE courses SET department_id = NULL WHERE department_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM departments WHERE id = ?")->execute([$id]);
            logActivity($pdo, currentUser()['id'], 'delete_department', "Deleted department #$id");
            $_SESSION['flash_success'] = 'Department deleted.';
        }
        header('Location: departments.php');
        exit;
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $pdo->prepare("UPDATE departments SET is_active = NOT is_active WHERE id = ?")->execute([$id]);
            $_SESSION['flash_success'] = 'Department status updated.';
        }
        header('Location: departments.php');
        exit;
    }
}

$rows = $pdo->query("
    SELECT d.*, (SELECT COUNT(*) FROM courses c WHERE c.department_id = d.id) AS course_count
    FROM departments d ORDER BY d.department_name
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <h1>Departments</h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDeptModal">
        <i class="bi bi-plus-lg me-1"></i> Add Department
    </button>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Courses</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No departments yet.</td></tr>
                <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td class="fw-semibold"><?= htmlspecialchars($r['department_name']) ?></td>
                    <td><?= htmlspecialchars($r['department_code'] ?? '—') ?></td>
                    <td><?= (int)$r['course_count'] ?></td>
                    <td>
                        <?php if ($r['is_active']): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                    <td class="text-end text-nowrap">
                        <button type="button" class="btn btn-sm btn-outline-primary"
                                data-bs-toggle="modal"
                                data-bs-target="#editDeptModal"
                                data-id="<?= $r['id'] ?>"
                                data-name="<?= htmlspecialchars($r['department_name'], ENT_QUOTES) ?>"
                                data-code="<?= htmlspecialchars($r['department_code'] ?? '', ENT_QUOTES) ?>"
                                data-desc="<?= htmlspecialchars($r['description'] ?? '', ENT_QUOTES) ?>"
                                title="Edit">
                            <i class="bi bi-pencil"></i>
                        </button>

                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-<?= $r['is_active'] ? 'warning' : 'success' ?>"
                                    title="<?= $r['is_active'] ? 'Disable' : 'Enable' ?>">
                                <?= $r['is_active'] ? 'Disable' : 'Enable' ?>
                            </button>
                        </form>

                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this department? Courses linked to it will be unassigned.');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Department Modal -->
<div class="modal fade" id="addDeptModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div class="modal-header">
                    <h5 class="modal-title">Add Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Department Name *</label>
                        <input type="text" name="department_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="department_code" class="form-control" placeholder="e.g. CIT">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Department Modal -->
<div class="modal fade" id="editDeptModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id" value="">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Department Name *</label>
                        <input type="text" name="department_name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="department_code" id="edit_code" class="form-control" placeholder="e.g. CIT">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="edit_desc" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('editDeptModal').addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    document.getElementById('edit_id').value   = btn.getAttribute('data-id');
    document.getElementById('edit_name').value = btn.getAttribute('data-name');
    document.getElementById('edit_code').value = btn.getAttribute('data-code');
    document.getElementById('edit_desc').value = btn.getAttribute('data-desc');
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>