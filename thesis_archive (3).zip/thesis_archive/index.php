<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';

if (isLoggedIn()) {
    redirectByRole();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thesis & Research Archive | Ramon Magsaysay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/thesis_archive/assets/css/style.css">
</head>
<body class="campus-bg d-flex align-items-center justify-content-center">
    <div class="auth-card text-center">
        <div class="mb-3">
            <i class="bi bi-journal-richtext text-primary" style="font-size: 3rem;"></i>
        </div>
        <h1 class="h3 fw-bold text-dark mb-1">Thesis &amp; Research Archive</h1>
        <p class="text-muted mb-4">Ramon Magsaysay &mdash; Academic Research Repository</p>
        <div class="d-grid gap-2">
            <a href="/thesis_archive/auth/login.php" class="btn btn-primary btn-lg">
                <i class="bi bi-box-arrow-in-right me-2"></i>Login
            </a>
            <a href="/thesis_archive/auth/register.php" class="btn btn-outline-primary">
                <i class="bi bi-person-plus me-2"></i>Create Student Account
            </a>
        </div>
        <p class="small text-muted mt-4 mb-0">For Faculty, Dean &amp; Admin accounts, contact the system administrator.</p>
    </div>
</body>
</html>
