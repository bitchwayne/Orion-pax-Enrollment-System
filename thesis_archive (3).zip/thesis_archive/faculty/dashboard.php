<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin(['faculty']);

$user = currentUser();
$pageTitle = 'Faculty Dashboard';

$deptId = $user['department_id'];

$totalMine = $pdo->prepare("SELECT COUNT(*) FROM thesis_research WHERE uploaded_by = ?");
$totalMine->execute([$user['id']]);
$totalMine = $totalMine->fetchColumn();

$pendingDept = 0;
$approvedDept = 0;
if ($deptId) {
    $s = $pdo->prepare("SELECT COUNT(*) FROM thesis_research WHERE department_id = ? AND status = 'pending'");
    $s->execute([$deptId]);
    $pendingDept = $s->fetchColumn();
    $s = $pdo->prepare("SELECT COUNT(*) FROM thesis_research WHERE department_id = ? AND status = 'approved'");
    $s->execute([$deptId]);
    $approvedDept = $s->fetchColumn();
}

$myRecent = $pdo->prepare("
    SELECT id, title, status, created_at FROM thesis_research
    WHERE uploaded_by = ? ORDER BY created_at DESC LIMIT 8
");
$myRecent->execute([$user['id']]);
$myRecent = $myRecent->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <div>
        <h1>Faculty Dashboard</h1>
        <p class="text-muted mb-0">Welcome, <?= htmlspecialchars($user['name']) ?></p>
    </div>
    <a href="research/add.php" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Upload Research</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="bi bi-file-earmark-text"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$totalMine ?></div>
                    <div class="small text-muted">My Uploads</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="bi bi-hourglass-split"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$pendingDept ?></div>
                    <div class="small text-muted">Pending (Dept)</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="bi bi-check-circle"></i></div>
                <div>
                    <div class="fs-4 fw-bold"><?= (int)$approvedDept ?></div>
                    <div class="small text-muted">Approved (Dept)</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card table-card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <strong>My Recent Uploads</strong>
        <a href="research/index.php" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr><th>Title</th><th>Status</th><th>Date</th></tr>
            </thead>
            <tbody>
                <?php if (empty($myRecent)): ?>
                    <tr><td colspan="3" class="text-center text-muted py-4">No uploads yet. <a href="research/add.php">Upload your first research</a></td></tr>
                <?php else: foreach ($myRecent as $r): ?>
                    <tr>
                        <td><a href="research/view.php?id=<?= $r['id'] ?>"><?= htmlspecialchars(mb_strimwidth($r['title'], 0, 60, '…')) ?></a></td>
                        <td><span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                        <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
