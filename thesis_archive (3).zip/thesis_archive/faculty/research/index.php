<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['faculty']);

$user = currentUser();
$pageTitle = 'My Research';

$q = trim($_GET['q'] ?? '');
$sql = "SELECT tr.*, d.department_name, c.course_name
        FROM thesis_research tr
        LEFT JOIN departments d ON d.id = tr.department_id
        LEFT JOIN courses c ON c.id = tr.course_id
        WHERE tr.uploaded_by = ?";
$params = [$user['id']];
if ($q !== '') {
    $sql .= " AND (tr.title LIKE ? OR tr.abstract LIKE ?)";
    $like = "%$q%";
    $params[] = $like;
    $params[] = $like;
}
$sql .= " ORDER BY tr.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <h1>My Research</h1>
    <a href="add.php" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Upload</a>
</div>

<div class="card table-card mb-3">
    <div class="card-body">
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="q" class="form-control search-box" placeholder="Search my research…" value="<?= htmlspecialchars($q) ?>">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Department</th>
                    <th>Year</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-5">No research uploaded yet.</td></tr>
                <?php else: foreach ($rows as $r): ?>
                    <tr>
                        <td><a href="view.php?id=<?= $r['id'] ?>" class="fw-semibold text-decoration-none"><?= htmlspecialchars(mb_strimwidth($r['title'], 0, 50, '…')) ?></a></td>
                        <td class="small"><?= htmlspecialchars($r['department_name'] ?? '—') ?></td>
                        <td><?= $r['publication_year'] ?? '—' ?></td>
                        <td><span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                        <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                        <td class="text-end">
                            <a href="view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
