-- ============================================================
-- Thesis & Research Archive System
-- School: Ramon Magsaysay
-- Database: thesis_archive
-- Compatible with MySQL 8+ / MariaDB (XAMPP)
-- ============================================================

CREATE DATABASE IF NOT EXISTS thesis_archive
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE thesis_archive;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS activity_logs;
DROP TABLE IF EXISTS access_requests;
DROP TABLE IF EXISTS thesis_keywords;
DROP TABLE IF EXISTS keywords;
DROP TABLE IF EXISTS thesis_authors;
DROP TABLE IF EXISTS authors;
DROP TABLE IF EXISTS thesis_research;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS departments;

SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- Departments
-- ------------------------------------------------------------
CREATE TABLE departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(150) NOT NULL UNIQUE,
    department_code VARCHAR(20) NULL,
    description TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Courses (linked to department)
-- ------------------------------------------------------------
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(150) NOT NULL,
    course_code VARCHAR(30) NULL,
    department_id INT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_courses_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Users (Admin, Dean, Faculty, Student)
-- ------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','dean','faculty','student') NOT NULL DEFAULT 'student',
    student_id VARCHAR(50) NULL,
    employee_id VARCHAR(50) NULL,
    department_id INT NULL,
    course_id INT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_users_course
        FOREIGN KEY (course_id) REFERENCES courses(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_users_role (role),
    INDEX idx_users_email (email)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Authors (can be students or external)
-- ------------------------------------------------------------
CREATE TABLE authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(150) NOT NULL,
    student_id VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Thesis / Research Records
-- ------------------------------------------------------------
CREATE TABLE thesis_research (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    abstract TEXT NULL,
    publication_year YEAR NULL,
    course_id INT NULL,
    department_id INT NULL,
    adviser_name VARCHAR(150) NULL,
    document_path VARCHAR(255) NULL,
    original_filename VARCHAR(255) NULL,
    file_size INT NULL,
    access_type ENUM('public','restricted') NOT NULL DEFAULT 'public',
    status ENUM('pending','approved','rejected','archived') NOT NULL DEFAULT 'pending',
    uploaded_by INT NOT NULL,
    approved_by INT NULL,
    approved_at DATETIME NULL,
    rejection_reason TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_thesis_course
        FOREIGN KEY (course_id) REFERENCES courses(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_thesis_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_thesis_uploader
        FOREIGN KEY (uploaded_by) REFERENCES users(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_thesis_approver
        FOREIGN KEY (approved_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_thesis_title (title),
    INDEX idx_thesis_year (publication_year),
    INDEX idx_thesis_status (status),
    INDEX idx_thesis_dept (department_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Thesis Authors (many-to-many)
-- ------------------------------------------------------------
CREATE TABLE thesis_authors (
    thesis_id INT NOT NULL,
    author_id INT NOT NULL,
    PRIMARY KEY (thesis_id, author_id),
    CONSTRAINT fk_thesis_authors_thesis
        FOREIGN KEY (thesis_id) REFERENCES thesis_research(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_thesis_authors_author
        FOREIGN KEY (author_id) REFERENCES authors(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Keywords
-- ------------------------------------------------------------
CREATE TABLE keywords (
    id INT AUTO_INCREMENT PRIMARY KEY,
    keyword VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE thesis_keywords (
    thesis_id INT NOT NULL,
    keyword_id INT NOT NULL,
    PRIMARY KEY (thesis_id, keyword_id),
    CONSTRAINT fk_thesis_keywords_thesis
        FOREIGN KEY (thesis_id) REFERENCES thesis_research(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_thesis_keywords_keyword
        FOREIGN KEY (keyword_id) REFERENCES keywords(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Access Requests (for restricted documents)
-- ------------------------------------------------------------
CREATE TABLE access_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    thesis_id INT NOT NULL,
    requester_id INT NOT NULL,
    reason TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    reviewed_by INT NULL,
    reviewed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_access_thesis
        FOREIGN KEY (thesis_id) REFERENCES thesis_research(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_access_requester
        FOREIGN KEY (requester_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_access_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_access_status (status)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Activity Logs
-- ------------------------------------------------------------
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    description TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_logs_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_logs_created_at (created_at)
) ENGINE=InnoDB;

-- ============================================================
-- Starter Data – Ramon Magsaysay Departments & Courses
-- ============================================================
INSERT INTO departments (department_name, department_code) VALUES
('College of Information Technology', 'CIT'),
('College of Computer Studies', 'CCS'),
('College of Business Administration', 'CBA'),
('College of Education', 'CED'),
('College of Engineering', 'COE'),
('College of Arts and Sciences', 'CAS');

INSERT INTO courses (course_name, course_code, department_id) VALUES
('BS Information Technology', 'BSIT', 1),
('BS Computer Science', 'BSCS', 2),
('Associate in Computer Technology', 'ACT', 1),
('BS Business Administration', 'BSBA', 3),
('BS Accountancy', 'BSA', 3),
('Bachelor of Elementary Education', 'BEED', 4),
('Bachelor of Secondary Education', 'BSED', 4),
('BS Civil Engineering', 'BSCE', 5),
('BS Psychology', 'BSPSY', 6);

-- Note: Create the first admin account by visiting setup_admin.php once after import.
