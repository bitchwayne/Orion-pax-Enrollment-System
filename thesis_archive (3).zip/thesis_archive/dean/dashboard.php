<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin(['dean']);

$user = currentUser();
$pageTitle = 'Dean Dashboard';
$deptId = $user['department_id'];

$deptName = 'Your Department';
if ($deptId) {
    $s = $pdo->prepare("SELECT department_name FROM departments WHERE id = ?");
    $s->execute([$deptId]);
    $deptName = $s->fetchColumn() ?: $deptName;
}

$pending = 0; $approved = 0; $total = 0;
if ($deptId) {
    $s = $pdo->prepare("SELECT COUNT(*) FROM thesis_research WHERE department_id = ? AND status = 'pending'");
    $s->execute([$deptId]); $pending = $s->fetchColumn();
    $s = $pdo->prepare("SELECT COUNT(*) FROM thesis_research WHERE department_id = ? AND status = 'approved'");
    $s->execute([$deptId]); $approved = $s->fetchColumn();
    $s = $pdo->prepare("SELECT COUNT(*) FROM thesis_research WHERE department_id = ?");
    $s->execute([$deptId]); $total = $s->fetchColumn();
}

$pendingList = [];
if ($deptId) {
    $s = $pdo->prepare("
        SELECT tr.id, tr.title, tr.created_at, u.name AS uploader
        FROM thesis_research tr
        LEFT JOIN users u ON u.id = tr.uploaded_by
        WHERE tr.department_id = ? AND tr.status = 'pending'
        ORDER BY tr.created_at ASC LIMIT 10
    ");
    $s->execute([$deptId]);
    $pendingList = $s->fetchAll();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <h1>Dean Dashboard</h1>
    <p class="text-muted mb-0"><?= htmlspecialchars($deptName) ?> &mdash; Welcome, <?= htmlspecialchars($user['name']) ?></p>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="bi bi-file-earmark-text"></i></div>
                <div><div class="fs-4 fw-bold"><?= (int)$total ?></div><div class="small text-muted">Total Research</div></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="bi bi-hourglass-split"></i></div>
                <div><div class="fs-4 fw-bold"><?= (int)$pending ?></div><div class="small text-muted">Pending Approval</div></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="bi bi-check-circle"></i></div>
                <div><div class="fs-4 fw-bold"><?= (int)$approved ?></div><div class="small text-muted">Approved</div></div>
            </div>
        </div>
    </div>
</div>

<div class="card table-card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <strong>Pending Approvals</strong>
        <a href="research/index.php" class="btn btn-sm btn-outline-primary">View All Department Research</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead><tr><th>Title</th><th>Uploader</th><th>Submitted</th><th class="text-end">Action</th></tr></thead>
            <tbody>
                <?php if (empty($pendingList)): ?>
                    <tr><td colspan="4" class="text-center text-muted py-4">No pending research.</td></tr>
                <?php else: foreach ($pendingList as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars(mb_strimwidth($r['title'], 0, 55, '…')) ?></td>
                        <td><?= htmlspecialchars($r['uploader'] ?? '—') ?></td>
                        <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                        <td class="text-end">
                            <a href="research/view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-primary">Review</a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
