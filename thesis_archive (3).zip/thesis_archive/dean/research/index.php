<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['dean']);

$user = currentUser();
$pageTitle = 'Department Research';
$deptId = $user['department_id'];

if (!$deptId) {
    $_SESSION['flash_error'] = 'Your account is not assigned to a department. Contact the administrator.';
    header('Location: ../dashboard.php');
    exit;
}

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';

$sql = "SELECT tr.*, c.course_name, u.name AS uploader_name
        FROM thesis_research tr
        LEFT JOIN courses c ON c.id = tr.course_id
        LEFT JOIN users u ON u.id = tr.uploaded_by
        WHERE tr.department_id = ?";
$params = [$deptId];
if ($q !== '') {
    $sql .= " AND (tr.title LIKE ? OR tr.abstract LIKE ?)";
    $like = "%$q%";
    $params[] = $like; $params[] = $like;
}
if ($status !== '') {
    $sql .= " AND tr.status = ?";
    $params[] = $status;
}
$sql .= " ORDER BY tr.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header"><h1>Department Research</h1></div>

<div class="card table-card mb-3">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-5">
                <input type="text" name="q" class="form-control" placeholder="Search…" value="<?= htmlspecialchars($q) ?>">
            </div>
            <div class="col-md-4">
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <?php foreach (['pending','approved','rejected','archived'] as $s): ?>
                        <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Course</th>
                    <th>Uploader</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-5">No research found.</td></tr>
                <?php else: foreach ($rows as $r): ?>
                    <tr>
                        <td><a href="view.php?id=<?= $r['id'] ?>" class="fw-semibold text-decoration-none"><?= htmlspecialchars(mb_strimwidth($r['title'], 0, 50, '…')) ?></a></td>
                        <td class="small"><?= htmlspecialchars($r['course_name'] ?? '—') ?></td>
                        <td class="small"><?= htmlspecialchars($r['uploader_name'] ?? '—') ?></td>
                        <td><span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                        <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                        <td class="text-end">
                            <a href="view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary">Review</a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
