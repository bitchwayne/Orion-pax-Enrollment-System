<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['dean']);

$user = currentUser();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$deptId = $user['department_id'];

$stmt = $pdo->prepare("
    SELECT tr.*, d.department_name, c.course_name, u.name AS uploader_name
    FROM thesis_research tr
    LEFT JOIN departments d ON d.id = tr.department_id
    LEFT JOIN courses c ON c.id = tr.course_id
    LEFT JOIN users u ON u.id = tr.uploaded_by
    WHERE tr.id = ? AND tr.department_id = ?
");
$stmt->execute([$id, $deptId]);
$r = $stmt->fetch();

if (!$r) {
    $_SESSION['flash_error'] = 'Research not found or not in your department.';
    header('Location: index.php');
    exit;
}

// Handle approve / reject
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $reason = trim($_POST['rejection_reason'] ?? '');
    if ($action === 'approve') {
        $pdo->prepare("UPDATE thesis_research SET status='approved', approved_by=?, approved_at=NOW(), rejection_reason=NULL WHERE id=?")
            ->execute([$user['id'], $id]);
        logActivity($pdo, $user['id'], 'approve_research', "Approved research #$id");
        $_SESSION['flash_success'] = 'Research approved.';
        header('Location: view.php?id=' . $id);
        exit;
    } elseif ($action === 'reject') {
        $pdo->prepare("UPDATE thesis_research SET status='rejected', approved_by=NULL, approved_at=NULL, rejection_reason=? WHERE id=?")
            ->execute([$reason ?: 'No reason provided', $id]);
        logActivity($pdo, $user['id'], 'reject_research', "Rejected research #$id");
        $_SESSION['flash_success'] = 'Research rejected.';
        header('Location: view.php?id=' . $id);
        exit;
    }
}

$authors = $pdo->prepare("SELECT a.author_name FROM thesis_authors ta JOIN authors a ON a.id = ta.author_id WHERE ta.thesis_id = ?");
$authors->execute([$id]);
$authorList = array_column($authors->fetchAll(), 'author_name');

$keywords = $pdo->prepare("SELECT k.keyword FROM thesis_keywords tk JOIN keywords k ON k.id = tk.keyword_id WHERE tk.thesis_id = ?");
$keywords->execute([$id]);
$keywordList = array_column($keywords->fetchAll(), 'keyword');

$pageTitle = 'Review Research';
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-start gap-2">
    <div>
        <h1 class="mb-1"><?= htmlspecialchars($r['title']) ?></h1>
        <span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span>
    </div>
    <a href="index.php" class="btn btn-outline-secondary btn-sm">Back</a>
</div>

<?php if ($r['status'] === 'pending'): ?>
<div class="card table-card mb-3 border-warning">
    <div class="card-body">
        <h6 class="mb-3">Approval Actions</h6>
        <form method="POST" class="d-flex flex-wrap gap-2 align-items-end">
            <button type="submit" name="action" value="approve" class="btn btn-success"
                    data-confirm="Approve this research?">
                <i class="bi bi-check-lg me-1"></i> Approve
            </button>
            <div class="flex-grow-1" style="min-width:200px">
                <input type="text" name="rejection_reason" class="form-control form-control-sm" placeholder="Rejection reason (optional)">
            </div>
            <button type="submit" name="action" value="reject" class="btn btn-danger"
                    data-confirm="Reject this research?">
                <i class="bi bi-x-lg me-1"></i> Reject
            </button>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card table-card mb-3">
            <div class="card-header bg-white"><strong>Abstract</strong></div>
            <div class="card-body">
                <?= $r['abstract'] ? nl2br(htmlspecialchars($r['abstract'])) : '<span class="text-muted">No abstract.</span>' ?>
            </div>
        </div>
        <?php if ($r['document_path']): ?>
        <div class="card table-card">
            <div class="card-body d-flex align-items-center gap-3">
                <i class="bi bi-file-earmark-pdf text-danger" style="font-size:2rem;"></i>
                <div><?= htmlspecialchars($r['original_filename'] ?? basename($r['document_path'])) ?></div>
                <a href="/thesis_archive/<?= htmlspecialchars($r['document_path']) ?>" class="btn btn-primary ms-auto" target="_blank">
                    <i class="bi bi-download me-1"></i>Download PDF
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-lg-4">
        <div class="card table-card">
            <div class="card-header bg-white"><strong>Details</strong></div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item d-flex justify-content-between"><span class="text-muted">Department</span><span><?= htmlspecialchars($r['department_name'] ?? '—') ?></span></li>
                <li class="list-group-item d-flex justify-content-between"><span class="text-muted">Course</span><span><?= htmlspecialchars($r['course_name'] ?? '—') ?></span></li>
                <li class="list-group-item d-flex justify-content-between"><span class="text-muted">Year</span><span><?= $r['publication_year'] ?? '—' ?></span></li>
                <li class="list-group-item d-flex justify-content-between"><span class="text-muted">Adviser</span><span><?= htmlspecialchars($r['adviser_name'] ?? '—') ?></span></li>
                <li class="list-group-item d-flex justify-content-between"><span class="text-muted">Uploader</span><span><?= htmlspecialchars($r['uploader_name'] ?? '—') ?></span></li>
                <li class="list-group-item"><div class="text-muted small mb-1">Authors</div><?= $authorList ? htmlspecialchars(implode(', ', $authorList)) : '—' ?></li>
                <li class="list-group-item">
                    <div class="text-muted small mb-1">Keywords</div>
                    <?php if ($keywordList): foreach ($keywordList as $kw): ?>
                        <span class="badge bg-light text-dark border me-1"><?= htmlspecialchars($kw) ?></span>
                    <?php endforeach; else: echo '—'; endif; ?>
                </li>
                <?php if ($r['status'] === 'rejected' && $r['rejection_reason']): ?>
                <li class="list-group-item">
                    <div class="text-muted small mb-1">Rejection Reason</div>
                    <?= htmlspecialchars($r['rejection_reason']) ?>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
