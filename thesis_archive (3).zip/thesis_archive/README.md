# Thesis & Research Archive System
**Ramon Magsaysay** — Academic Research Repository

A fully functional web-based archive for theses and research papers, designed for multiple college departments, courses, deans, faculty/teachers, and students.

---

## Requirements

- **XAMPP** (Apache + MySQL/MariaDB)
- PHP 8.0 or higher
- Modern web browser

---

## Installation

1. **Copy the project**
   - Place the entire `thesis_archive` folder into:
     ```
     C:\xampp\htdocs\thesis_archive
     ```

2. **Start XAMPP**
   - Start **Apache** and **MySQL**.

3. **Create the database**
   - Open http://localhost/phpmyadmin
   - Click **Import**
   - Choose `database.sql` from the project folder
   - Click **Go**
   - This creates the database `thesis_archive` and all tables + starter departments/courses.

4. **Create the admin account**
   - Open: http://localhost/thesis_archive/setup_admin.php
   - You will see the admin credentials.
   - **Delete `setup_admin.php` immediately** after success.

5. **Login**
   - URL: http://localhost/thesis_archive/
   - **Admin**
     - Email: `admin@thesisarchive.com`
     - Password: `Admin12345`
   - Change this password after first login (or create a new admin and disable the default one).

---

## Default Roles

| Role     | Capabilities |
|----------|--------------|
| **Admin**   | Full control: users, departments, courses, all research (add/edit/delete/approve), activity logs |
| **Dean**    | View & approve/reject research in their assigned department |
| **Faculty** | Upload research (pending approval), view own uploads |
| **Student** | Register, browse approved research, request access to restricted documents |

---

## Creating Faculty / Dean Accounts

1. Login as **Admin**
2. Go to **Users** → **Add User**
3. Set role to `faculty` or `dean`
4. Assign a **Department** (required for Dean and recommended for Faculty)
5. Share the credentials with the staff member

Students can self-register from the home page.

---

## Features

- Multi-role authentication (Admin, Dean, Faculty, Student)
- Department & Course management
- Research upload with PDF (max 10 MB)
- Authors & keywords
- Public / Restricted access
- Approval workflow (Faculty upload → Dean/Admin approve)
- Search & filter by title, department, year, status
- Activity logging
- Responsive Bootstrap 5 UI
- Secure password hashing (bcrypt)
- Prepared statements (PDO) against SQL injection

---

## Folder Structure

```
thesis_archive/
├── admin/           # Admin panel
├── auth/            # Login, register, logout
├── config/          # Database & auth helpers
├── dean/            # Dean panel
├── faculty/         # Faculty panel
├── student/         # Student panel
├── includes/        # Header & footer
├── assets/          # CSS, JS, images
├── uploads/research/# PDF storage
├── database.sql
├── setup_admin.php  # Run once, then delete
├── index.php
└── README.md
```

---

## Customization

- Replace `assets/images/campus-bg.png` with your campus photo.
- Update school name in `includes/header.php` and `index.php` if needed.
- Add more departments/courses via the Admin panel.

---

## Security Notes

- Delete `setup_admin.php` after creating the admin.
- Change the default admin password.
- Keep XAMPP and PHP updated.
- This system is intended for school intranet / controlled deployment. For public internet use, add HTTPS, stronger session settings, and rate limiting.

---

## Support

For school project use. Built for Ramon Magsaysay Thesis & Research Archive.
