<?php
/**
 * Authentication & Authorization Helpers
 * Thesis & Research Archive – Ramon Magsaysay
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Normalize role string to lowercase for consistent comparison
 */
function normalizeRole($role): string {
    return strtolower(trim((string)$role));
}

/**
 * Require login and optionally restrict by role(s)
 * @param array|string|null $allowedRoles  e.g. ['admin'], 'faculty', or null (any logged-in user)
 */
function requireLogin($allowedRoles = null) {
    // Not logged in at all
    if (empty($_SESSION['user_id'])) {
        header('Location: /thesis_archive/auth/login.php?error=login_required');
        exit;
    }

    // Role missing from session (old session / incomplete login) → force re-login
    if (empty($_SESSION['user_role'])) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        header('Location: /thesis_archive/auth/login.php?error=login_required');
        exit;
    }

    if ($allowedRoles !== null) {
        $roles = is_array($allowedRoles) ? $allowedRoles : [$allowedRoles];
        // Normalize both sides so "Student" / "student" / "STUDENT" all match
        $roles = array_map('normalizeRole', $roles);
        $currentRole = normalizeRole($_SESSION['user_role']);

        if (!in_array($currentRole, $roles, true)) {
            http_response_code(403);
            echo '<!DOCTYPE html><html><head><title>Access Denied</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                </head><body class="bg-light d-flex align-items-center justify-content-center min-vh-100">
                <div class="card shadow text-center p-5" style="max-width:420px">
                    <h2 class="text-danger">Access Denied</h2>
                    <p class="text-muted">Your account role (<strong>' . htmlspecialchars($currentRole) . '</strong>) does not have permission to view this page.</p>
                    <p class="small text-muted">Try logging out and logging in again.</p>
                    <a href="/thesis_archive/auth/logout.php" class="btn btn-primary">Logout &amp; Return to Login</a>
                </div></body></html>';
            exit;
        }
    }
}

function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']) && !empty($_SESSION['user_role']);
}

function currentUser(): ?array {
    if (!isLoggedIn()) return null;
    return [
        'id'            => (int)$_SESSION['user_id'],
        'name'          => $_SESSION['user_name'] ?? '',
        'email'         => $_SESSION['user_email'] ?? '',
        'role'          => normalizeRole($_SESSION['user_role'] ?? ''),
        'department_id' => $_SESSION['department_id'] ?? null,
        'course_id'     => $_SESSION['course_id'] ?? null,
    ];
}

function redirectByRole(): void {
    $role = normalizeRole($_SESSION['user_role'] ?? '');
    switch ($role) {
        case 'admin':
            header('Location: /thesis_archive/admin/dashboard.php');
            break;
        case 'dean':
            header('Location: /thesis_archive/dean/dashboard.php');
            break;
        case 'faculty':
            header('Location: /thesis_archive/faculty/dashboard.php');
            break;
        case 'student':
            header('Location: /thesis_archive/student/dashboard.php');
            break;
        default:
            header('Location: /thesis_archive/auth/login.php?error=unauthorized');
            break;
    }
    exit;
}

/**
 * Log an activity (safe – never breaks main flow)
 */
function logActivity(PDO $pdo, ?int $userId, string $action, string $description = ''): void {
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $userId,
            $action,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null
        ]);
    } catch (Exception $e) {
        // Silent fail for logging
    }
}
?>