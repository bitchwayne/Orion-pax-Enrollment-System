<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['student']);

$user = currentUser();
$pageTitle = 'My Uploads';

$stmt = $pdo->prepare("
    SELECT tr.*, d.department_name, c.course_name
    FROM thesis_research tr
    LEFT JOIN departments d ON d.id = tr.department_id
    LEFT JOIN courses c ON c.id = tr.course_id
    WHERE tr.uploaded_by = ?
    ORDER BY tr.created_at DESC
");
$stmt->execute([$user['id']]);
$rows = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <h1>My Uploads</h1>
    <a href="add.php" class="btn btn-primary"><i class="bi bi-upload me-1"></i> Upload New</a>
</div>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Department</th>
                    <th>Year</th>
                    <th>Status</th>
                    <th>Submitted</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-5">
                            You have not uploaded any research yet.
                            <a href="add.php">Upload your first thesis</a>
                        </td>
                    </tr>
                <?php else: foreach ($rows as $r): ?>
                    <tr>
                        <td class="fw-semibold"><?= htmlspecialchars(mb_strimwidth($r['title'], 0, 55, '…')) ?></td>
                        <td class="small"><?= htmlspecialchars($r['department_name'] ?? '—') ?></td>
                        <td><?= $r['publication_year'] ?? '—' ?></td>
                        <td>
                            <span class="badge badge-status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span>
                            <?php if ($r['status'] === 'rejected' && !empty($r['rejection_reason'])): ?>
                                <div class="small text-danger mt-1"><?= htmlspecialchars($r['rejection_reason']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="small text-muted"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>