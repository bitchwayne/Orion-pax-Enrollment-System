<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/auth.php';
requireLogin(['student']);

$pageTitle = 'Browse Research';

$q = trim($_GET['q'] ?? '');
$dept = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
$year = isset($_GET['year']) ? (int)$_GET['year'] : 0;

$sql = "SELECT tr.id, tr.title, tr.abstract, tr.publication_year, tr.access_type, tr.document_path,
               d.department_name, c.course_name
        FROM thesis_research tr
        LEFT JOIN departments d ON d.id = tr.department_id
        LEFT JOIN courses c ON c.id = tr.course_id
        WHERE tr.status = 'approved'";
$params = [];
if ($q !== '') {
    $sql .= " AND (tr.title LIKE ? OR tr.abstract LIKE ? OR tr.adviser_name LIKE ?)";
    $like = "%$q%";
    $params = array_merge($params, [$like, $like, $like]);
}
if ($dept > 0) {
    $sql .= " AND tr.department_id = ?";
    $params[] = $dept;
}
if ($year > 0) {
    $sql .= " AND tr.publication_year = ?";
    $params[] = $year;
}
$sql .= " ORDER BY tr.publication_year DESC, tr.title ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$departments = $pdo->query("SELECT id, department_name FROM departments WHERE is_active = 1 ORDER BY department_name")->fetchAll();
$years = $pdo->query("SELECT DISTINCT publication_year FROM thesis_research WHERE status='approved' AND publication_year IS NOT NULL ORDER BY publication_year DESC")->fetchAll(PDO::FETCH_COLUMN);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header"><h1>Browse Research</h1></div>

<div class="card table-card mb-3">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Title, abstract, adviser…" value="<?= htmlspecialchars($q) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Department</label>
                <select name="department_id" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= $d['id'] ?>" <?= $dept === (int)$d['id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['department_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Year</label>
                <select name="year" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($years as $y): ?>
                        <option value="<?= $y ?>" <?= $year === (int)$y ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search me-1"></i> Search</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <?php if (empty($rows)): ?>
        <div class="col-12">
            <div class="card table-card">
                <div class="card-body text-center text-muted py-5">No approved research found matching your criteria.</div>
            </div>
        </div>
    <?php else: foreach ($rows as $r): ?>
        <div class="col-md-6 col-xl-4">
            <div class="card table-card h-100">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex gap-2 mb-2">
                        <span class="badge badge-access-<?= $r['access_type'] ?>"><?= ucfirst($r['access_type']) ?></span>
                        <?php if ($r['publication_year']): ?>
                            <span class="badge bg-secondary"><?= $r['publication_year'] ?></span>
                        <?php endif; ?>
                    </div>
                    <h5 class="card-title h6 fw-bold"><?= htmlspecialchars(mb_strimwidth($r['title'], 0, 80, '…')) ?></h5>
                    <p class="card-text small text-muted abstract-preview flex-grow-1">
                        <?= htmlspecialchars($r['abstract'] ?? 'No abstract available.') ?>
                    </p>
                    <div class="small text-muted mb-2">
                        <?= htmlspecialchars($r['department_name'] ?? '') ?>
                        <?= $r['course_name'] ? ' · ' . htmlspecialchars($r['course_name']) : '' ?>
                    </div>
                    <a href="view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary align-self-start">View Details</a>
                </div>
            </div>
        </div>
    <?php endforeach; endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
