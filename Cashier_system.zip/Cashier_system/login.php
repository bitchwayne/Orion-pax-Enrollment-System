<?php
session_start();
include 'db.php';

if (isset($_POST['update_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    $staff_id = $_SESSION['staff_id'];

    // 1. Get current hash from DB
    $stmt = $pdo->prepare("SELECT password FROM staff WHERE id = ?");
    $stmt->execute([$staff_id]);
    $user = $stmt->fetch();

    if (password_verify($current, $user['password'])) {
        if ($new === $confirm) {
            $newHash = password_hash($new, PASSWORD_DEFAULT);
            $update = $pdo->prepare("UPDATE staff SET password = ? WHERE id = ?");
            $update->execute([$newHash, $staff_id]);
            $msg = ["success", "Password updated successfully!"];
        } else {
            $msg = ["danger", "New passwords do not match!"];
        }
    } else {
        $msg = ["danger", "Current password is incorrect!"];
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login | UniPay</title>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <link rel="stylesheet" href="https://cloudflare.com">
    <style>
        :root {
            --primary-blue: #0d47a1;
            --secondary-blue: #1565c0;
            --soft-blue: #e3f2fd;
        }

        body {
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--secondary-blue) 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }

        .login-card {
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            border: none;
        }

        .login-logo {
            color: var(--primary-blue);
            font-size: 3rem;
            margin-bottom: 10px;
        }

        .form-control {
            border-radius: 10px;
            padding: 12px;
            border: 1px solid #ddd;
            background: #f9f9f9;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px var(--soft-blue);
            border-color: var(--primary-blue);
        }

        .btn-login {
            background: var(--primary-blue);
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: bold;
            transition: 0.3s;
            color: white;
        }

        .btn-login:hover {
            background: #0a3d8a;
            transform: translateY(-2px);
            color: white;
        }

        .system-title {
            font-weight: 800;
            color: var(--primary-blue);
            letter-spacing: 1px;
        }
        
        .footer-text {
            color: #888;
            font-size: 0.85rem;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="login-card text-center">
    <div class="login-logo">
        <i class="fas fa-university"></i>
    </div>
    <h2 class="system-title mb-1">UniPay</h2>
    <p class="text-muted mb-4">Cashier Portal Access</p>

    <?php if(isset($error)): ?>
        <div class="alert alert-danger py-2" style="font-size: 0.9rem;">
            <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3 text-start">
            <label class="form-label text-muted small fw-bold">USERNAME</label>
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0 text-muted"><i class="fas fa-user"></i></span>
                <input type="text" name="username" class="form-control border-start-0 ps-0" placeholder="Enter username" required>
            </div>
        </div>

        <div class="mb-4 text-start">
            <label class="form-label text-muted small fw-bold">PASSWORD</label>
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0 text-muted"><i class="fas fa-lock"></i></span>
                <input type="password" name="password" class="form-control border-start-0 ps-0" placeholder="Enter password" required>
            </div>
        </div>

        <button type="submit" name="login" class="btn btn-login w-100 shadow">
            SIGN IN <i class="fas fa-arrow-right ms-2"></i>
        </button>
    </form>

    <div class="footer-text">
        &copy; <?php echo date('Y'); ?> University Tuition System <br>
        <span class="badge bg-light text-dark mt-2 border">Authorized Staff Only</span>
    </div>
</div>

</body>
</html>
