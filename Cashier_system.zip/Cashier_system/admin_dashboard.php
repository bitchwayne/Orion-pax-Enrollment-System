<?php
session_start();
if (!isset($_SESSION['staff_id'])) { header("Location: login.php"); exit(); }
include 'db.php';

$feedback = "";

// --- LOGIC: CHANGE PASSWORD ---
if (isset($_POST['update_pass'])) {
    $stmt = $pdo->prepare("SELECT password FROM staff WHERE id = ?");
    $stmt->execute([$_SESSION['staff_id']]);
    $user = $stmt->fetch();

    if (password_verify($_POST['old_p'], $user['password'])) {
        $pdo->prepare("UPDATE staff SET password = ? WHERE id = ?")->execute([password_hash($_POST['new_p'], PASSWORD_DEFAULT), $_SESSION['staff_id']]);
        $feedback = "<script>alert('✅ Password updated successfully!');</script>";
    } else {
        $feedback = "<script>alert('❌ Incorrect current password.');</script>";
    }
}

// (Keep your existing Call Next and Payment Logic here)
$serving = $pdo->query("SELECT q.*, s.full_name, s.student_no, s.balance FROM queue q JOIN students s ON q.student_id = s.id WHERE q.status = 'Serving' LIMIT 1")->fetch();
$waiting = $pdo->query("SELECT q.*, s.full_name FROM queue q JOIN students s ON q.student_id = s.id WHERE q.status = 'Waiting' ORDER BY q.created_at ASC")->fetchAll();
$total_today = $pdo->query("SELECT SUM(amount_paid) FROM transactions WHERE DATE(payment_date) = CURDATE()")->fetchColumn() ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UniPay | Premium Dashboard</title>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <link rel="stylesheet" href="https://cloudflare.com">
    <style>
        :root { --navy: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; display: flex; }
        
        .sidebar { width: 280px; height: 100vh; background: var(--navy); color: white; position: fixed; padding: 2rem 1.5rem; display: flex; flex-column; }
        .main-content { margin-left: 280px; padding: 3rem; width: 100%; }

        .nav-link { color: #94a3b8; padding: 12px; border-radius: 12px; transition: 0.3s; margin-bottom: 5px; }
        .nav-link:hover, .nav-link.active { background: #1e293b; color: white; }

        /* Profile Section at Bottom */
        .profile-trigger { 
            cursor: pointer; 
            padding: 15px; 
            background: #1e293b; 
            border-radius: 15px; 
            transition: 0.3s; 
        }
        .profile-trigger:hover { background: #334155; }

        .premium-card { background: white; border-radius: 24px; padding: 2rem; border: 1px solid #e2e8f0; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.02); }
        .btn-call { background: var(--primary-blue); color: white; border-radius: 14px; padding: 12px 24px; border: none; font-weight: 600; }
    </style>
</head>
<body>

<?php echo $feedback; ?>

<!-- SIDEBAR -->
<div class="sidebar d-flex flex-column">
    <div class="mb-5">
        <h3 class="fw-bold m-0 text-white">UniPay<span class="text-primary">.</span></h3>
    </div>
    
    <div class="nav flex-column mb-auto">
        <a href="#" class="nav-link active"><i class="fas fa-home me-2"></i> Dashboard</a>
        <a href="monitor.php" target="_blank" class="nav-link"><i class="fas fa-desktop me-2"></i> TV Monitor</a>
    </div>

    <!-- Hidden Settings Access (Only shown if clicked) -->
    <div class="profile-trigger d-flex align-items-center justify-content-between mt-auto" data-bs-toggle="modal" data-bs-target="#confirmSettingsModal">
        <div class="d-flex align-items-center">
            <div class="bg-primary rounded-circle me-3" style="width: 35px; height: 35px; display:flex; align-items:center; justify-content:center;">
                <i class="fas fa-user-tie text-white small"></i>
            </div>
            <div class="overflow-hidden">
                <p class="m-0 small fw-bold text-white"><?php echo $_SESSION['staff_name']; ?></p>
            </div>
        </div>
        <i class="fas fa-cog text-muted"></i>
    </div>
</div>

<div class="main-content">
    <!-- Rest of your dashboard UI here (Serving Panel, Waiting List, etc.) -->
    <div class="d-flex justify-content-between align-items-center mb-5">
        <h1>Terminal Overview</h1>
        <div class="premium-card py-2 px-4">
            <small class="text-muted fw-bold">TOTAL TODAY</small>
            <h3 class="m-0 text-primary fw-bold">₱<?php echo number_format($total_today, 2); ?></h3>
        </div>
    </div>
    
    <!-- (Include the serving panel and queue list from previous version here) -->
</div>

<!-- STEP 1: CONFIRMATION UI (The "Whether to change or not" screen) -->
<div class="modal fade" id="confirmSettingsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 400px;">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
            <div class="modal-body text-center p-5">
                <div class="mb-4">
                    <i class="fas fa-shield-alt fa-4x text-primary opacity-25"></i>
                </div>
                <h4 class="fw-bold">Security Settings</h4>
                <p class="text-muted">Would you like to update your login password or logout from the session?</p>
                
                <div class="d-grid gap-2 mt-4">
                    <!-- If they click this, it opens the actual form -->
                    <button class="btn btn-primary p-3 fw-bold rounded-3" data-bs-target="#actualPassForm" data-bs-toggle="modal">
                        <i class="fas fa-key me-2"></i> Yes, Change Password
                    </button>
                    <a href="logout.php" class="btn btn-outline-danger p-3 fw-bold rounded-3">
                        <i class="fas fa-sign-out-alt me-2"></i> No, Just Logout
                    </a>
                    <button class="btn btn-link text-muted mt-2" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- STEP 2: ACTUAL CHANGE PASSWORD FORM -->
<div class="modal fade" id="actualPassForm" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
            <div class="modal-header border-0 p-4 pb-0">
                <h5 class="fw-bold">Update Access Credentials</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="small fw-bold mb-2">CURRENT PASSWORD</label>
                    <input type="password" name="old_p" class="form-control p-3 bg-light border-0" required>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-2">NEW PASSWORD</label>
                    <input type="password" name="new_p" class="form-control p-3 bg-light border-0" required>
                </div>
            </div>
            <div class="modal-footer border-0 p-4">
                <button type="submit" name="update_pass" class="btn btn-primary w-100 p-3 fw-bold rounded-3">Update Now</button>
            </div>
        </form>
    </div>
</div>

<script src="https://jsdelivr.net"></script>

</body>
</html>
