<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh" content="5"> <!-- Refresh every 5 seconds for live feel -->
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Queue Monitor Display</title>
    <style>
        .now-serving-box { background: #0d6efd; color: white; padding: 40px; border-radius: 15px; }
        .ticket-num { font-size: 5rem; font-weight: bold; }
    </style>
</head>
<body class="bg-dark text-white p-5">
    <div class="container-fluid">
        <div class="row">
            <!-- Left: Now Serving -->
            <div class="col-md-6 text-center">
                <div class="now-serving-box shadow">
                    <h1>NOW SERVING</h1>
                    <?php
                    $serving = $pdo->query("SELECT q.ticket_no, s.full_name FROM queue q 
                                            JOIN students s ON q.student_id = s.id 
                                            WHERE q.status = 'Serving' LIMIT 1")->fetch();
                    if ($serving) {
                        echo "<div class='ticket-num'>{$serving['ticket_no']}</div>";
                        echo "<h3>{$serving['full_name']}</h3>";
                    } else {
                        echo "<div class='ticket-num'>---</div><h3>Wait for Next</h3>";
                    }
                    ?>
                </div>
            </div>

            <!-- Right: Queue List with Balance -->
            <div class="col-md-6">
                <h2 class="mb-4">Waiting List</h2>
                <table class="table table-dark table-striped h4">
                    <thead>
                        <tr><th>Ticket</th><th>Student Name</th><th>Current Balance</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $waiting = $pdo->query("SELECT q.ticket_no, s.full_name, s.balance FROM queue q 
                                                JOIN students s ON q.student_id = s.id 
                                                WHERE q.status = 'Waiting' ORDER BY q.created_at ASC LIMIT 8")->fetchAll();
                        foreach ($waiting as $row): ?>
                        <tr>
                            <td><span class="badge bg-warning text-dark"><?php echo $row['ticket_no']; ?></span></td>
                            <td><?php echo $row['full_name']; ?></td>
                            <td class="text-danger">$<?php echo number_format($row['balance'], 2); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
