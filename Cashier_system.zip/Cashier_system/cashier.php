<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Cashier Dashboard</title>
</head>
<body class="p-4">
    <div class="row">
        <!-- Queue Management -->
        <div class="col-md-4">
            <h3>Queue</h3>
            <ul class="list-group">
                <?php
                $waiting = $pdo->query("SELECT q.*, s.full_name FROM queue q JOIN students s ON q.student_id = s.id WHERE q.status = 'Waiting' ORDER BY q.created_at ASC")->fetchAll();
                foreach($waiting as $q) {
                    echo "<li class='list-group-item d-flex justify-content-between'>{$q['ticket_no']} - {$q['full_name']} 
                          <a href='?serve={$q['id']}' class='btn btn-sm btn-success'>Call</a></li>";
                }
                ?>
            </ul>
        </div>

        <!-- Serving & Payment -->
        <div class="col-md-8">
            <h3>Currently Serving</h3>
            <?php
            if(isset($_GET['serve'])) {
                $pdo->prepare("UPDATE queue SET status = 'Serving' WHERE id = ?")->execute([$_GET['serve']]);
            }
            $current = $pdo->query("SELECT q.*, s.full_name, s.balance FROM queue q JOIN students s ON q.student_id = s.id WHERE q.status = 'Serving' LIMIT 1")->fetch();
            
            if($current): ?>
                <div class="card p-3">
                    <h4>Serving: <?php echo $current['full_name']; ?> (<?php echo $current['ticket_no']; ?>)</h4>
                    <p>Balance: $<?php echo number_format($current['balance'], 2); ?></p>
                    <form method="POST">
                        <input type="hidden" name="qid" value="<?php echo $current['id']; ?>">
                        <input type="hidden" name="sid" value="<?php echo $current['student_id']; ?>">
                        <input type="number" name="amount" class="form-control mb-2" placeholder="Amount to Pay" required>
                        <button type="submit" name="pay" class="btn btn-primary">Complete Payment</button>
                    </form>
                </div>
            <?php else: ?>
                <p>No student currently being served.</p>
            <?php endif; ?>

            <?php
            if(isset($_POST['pay'])) {
                // Update balance, record transaction, and close queue ticket
                $pdo->prepare("UPDATE students SET balance = balance - ? WHERE id = ?")->execute([$_POST['amount'], $_POST['sid']]);
                $pdo->prepare("INSERT INTO transactions (student_id, amount_paid) VALUES (?, ?)")->execute([$_POST['sid'], $_POST['amount']]);
                $pdo->prepare("UPDATE queue SET status = 'Completed' WHERE id = ?")->execute([$_POST['qid']]);
                header("Location: cashier.php");
            }
            ?>
        </div>
    </div>
</body>
</html>
