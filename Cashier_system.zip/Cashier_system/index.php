<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Student Kiosk</title>
</head>
<body class="bg-light d-flex align-items-center vh-100">
    <div class="container text-center" style="max-width: 400px;">
        <div class="card shadow p-4">
            <h2>Get Your Ticket</h2>
            <form method="POST">
                <input type="text" name="student_no" class="form-control mb-3" placeholder="Enter Student Number" required>
                <button type="submit" name="get_ticket" class="btn btn-primary w-100">Get Ticket</button>
            </form>
            <?php
            if(isset($_POST['get_ticket'])) {
                $stmt = $pdo->prepare("SELECT id FROM students WHERE student_no = ?");
                $stmt->execute([$_POST['student_no']]);
                $student = $stmt->fetch();
                if($student) {
                    $ticket = "T-" . rand(100, 999);
                    $pdo->prepare("INSERT INTO queue (student_id, ticket_no) VALUES (?, ?)")->execute([$student['id'], $ticket]);
                    echo "<div class='alert alert-success mt-3'>Your Ticket: <strong>$ticket</strong></div>";
                } else {
                    echo "<div class='alert alert-danger mt-3'>Student Not Found!</div>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
