<?php
session_start();
include('db_connection.php');

// Using REQUEST_METHOD is more reliable than checking button name
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Successful login
        $_SESSION['student_id'] = $user['student_id'];
        $_SESSION['course'] = $user['course_id']; // Ensure this column exists in DB
        $_SESSION['full_name'] = $user['first_name'] . " " . $user['last_name'];

        header("Location: studyload.php");
        exit();
    } else {
        echo "Invalid ID or Password. <a href='login.html'>Try again</a>";
    }
} else {
    header("Location: login.html");
    exit();
}
?>
