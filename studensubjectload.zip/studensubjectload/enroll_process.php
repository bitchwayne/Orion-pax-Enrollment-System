<?php
session_start();
include('db_connection.php');

if (isset($_POST['enroll_btn']) && isset($_SESSION['student_id'])) {
    $student_id = $_SESSION['student_id'];
    $subject_code = $_POST['subject_code'];

    try {
        // Prevent duplicate enrollment
        $check = $pdo->prepare("SELECT * FROM student_load WHERE student_id = ? AND subject_code = ?");
        $check->execute([$student_id, $subject_code]);
        
        if ($check->rowCount() > 0) {
            echo "<script>alert('Already enrolled in this subject!'); window.location.href='studyload.php';</script>";
        } else {
            $stmt = $pdo->prepare("INSERT INTO student_load (student_id, subject_code) VALUES (?, ?)");
            $stmt->execute([$student_id, $subject_code]);
            echo "<script>alert('Successfully enrolled in $subject_code!'); window.location.href='studyload.php';</script>";
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>
