<?php
session_start();
include('db_connection.php');

if (isset($_POST['enroll_btn']) && isset($_SESSION['student_id'])) {
    $student_id = $_SESSION['student_id'];
    $subject_id = $_POST['subject_id'];

    try {
        // Prepare to save the selection. Ensure you have a 'student_load' table.
        $sql = "INSERT INTO student_load (student_id, subject_code) VALUES (?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$student_id, $subject_id]);

        echo "<script>alert('Subject Enrolled Successfully!'); window.location.href='studyload.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Error: You might already be enrolled in this subject.'); window.location.href='studyload.php';</script>";
    }
}
?>
