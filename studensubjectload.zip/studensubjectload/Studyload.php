<?php
session_start();
include('db_connection.php');

// 1. SECURITY: Redirect to login if not authenticated
if (!isset($_SESSION['student_id'])) {
    header("Location: login.html");
    exit();
}

$id = $_SESSION['student_id'];

try {
    // 2. FETCH STUDENT INFO
    $stmt = $pdo->prepare("SELECT first_name, last_name, course_id, status FROM students WHERE student_id = ?");
    $stmt->execute([$id]);
    $student = $stmt->fetch();

    if (!$student) { die("Student record missing."); }

    $full_name = $student['first_name'] . " " . $student['last_name'];
    $course = trim($student['course_id']); 

    // 3. FETCH SUBJECTS (Filtered by the student's Course)
    $subjects = [];
    if (!empty($course)) {
        $query = "SELECT * FROM subjectssem120182019 WHERE TRIM(COURSE) = :course AND OPEN = 1";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':course' => $course]);
        $subjects = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>SubjectLoad Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; padding: 20px; }
        .container { max-width: 1100px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding-bottom: 15px; margin-bottom: 20px; }
        .nav-links a { text-decoration: none; margin-left: 20px; font-weight: bold; color: #555; }
        .alert { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin-bottom: 20px; border: 1px solid #ffeeba; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #007bff; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #ddd; }
        .btn-enroll { background: #28a745; color: white; border: none; padding: 8px 15px; cursor: pointer; border-radius: 5px; font-weight: bold; }
        .btn-enroll:hover { background: #218838; }
        .badge { background: #e7f3ff; color: #007bff; padding: 5px 12px; border-radius: 20px; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <!-- PASSWORD CHANGE ALERT -->
    <?php if ($student['status'] == 'new'): ?>
        <div class="alert">
            ⚠️ <strong>Security Notice:</strong> You are using a temporary password. 
            <a href="change_password.php" style="color: #856404; text-decoration: underline;">Change it now</a>.
        </div>
    <?php endif; ?>

    <div class="header">
        <div>
            <h1>Welcome, <?php echo htmlspecialchars($full_name); ?></h1>
            <span class="badge">Program: <?php echo htmlspecialchars($course ?: 'Unassigned'); ?></span>
        </div>
        <div class="nav-links">
            <a href="change_password.php">Change Password</a>
            <a href="logout.php" style="color: #dc3545;">Logout</a>
        </div>
    </div>

    <h3>Available Subjects</h3>
    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Description</th>
                <th>Units</th>
                <th>Schedule</th>
                <th>Room</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($subjects): ?>
                <?php foreach ($subjects as $row): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($row['SUBJECT']); ?></strong></td>
                    <td><?php echo htmlspecialchars($row['DESC']); ?></td>
                    <td><?php echo htmlspecialchars($row['UNIT']); ?></td>
                    <td><?php echo htmlspecialchars($row['TSTART'] . " - " . $row['TEND']); ?></td>
                    <td><?php echo htmlspecialchars($row['ROOM']); ?></td>
                    <td>
                        <form action="enroll_process.php" method="POST">
                            <input type="hidden" name="subject_code" value="<?php echo $row['SUBJECT']; ?>">
                            <button type="submit" name="enroll_btn" class="btn-enroll">Enroll</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center; padding: 40px; color: #999;">No subjects found. Ensure your course matches the database.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
