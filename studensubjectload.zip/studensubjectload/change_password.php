<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['student_id'])) { header("Location: login.html"); exit(); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current = $_POST['current_pass'];
    $new = $_POST['new_pass'];
    
    $stmt = $pdo->prepare("SELECT password FROM students WHERE student_id = ?");
    $stmt->execute([$_SESSION['student_id']]);
    $user = $stmt->fetch();

    if ($user && password_verify($current, $user['password'])) {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE students SET password = ?, status = 'active' WHERE student_id = ?");
        $update->execute([$hashed, $_SESSION['student_id']]);
        echo "<script>alert('Password updated!'); window.location.href='studyload.php';</script>";
    } else {
        echo "<script>alert('Current password incorrect!');</script>";
    }
}
?>
<!-- Add a simple HTML form here with Current and New password inputs -->
