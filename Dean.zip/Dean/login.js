function showRegistration() {
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('registerScreen').classList.remove('hidden');
}

function showLogin() {
    document.getElementById('registerScreen').classList.add('hidden');
    document.getElementById('loginScreen').classList.remove('hidden');
}

function handleRegister(e) {
    e.preventDefault();
    alert("Account created! Please login with your credentials.");
    showLogin();
}

function handleLogout() {
    // In a real app, clear sessions here
    document.getElementById('loginScreen').classList.remove('hidden');
}
// Example login logic inside login.js
function handleLogin() {
    // ... after validating credentials ...
    localStorage.setItem('isLoggedIn', 'true');
    window.location.href = "dean.html";
}
