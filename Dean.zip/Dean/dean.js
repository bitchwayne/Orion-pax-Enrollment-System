document.addEventListener('DOMContentLoaded', () => {
    // Elements
    const loginScreen = document.getElementById('loginScreen');
    const loginForm = document.getElementById('loginForm');
    const logoutBtn = document.getElementById('logoutBtn');
    
    const pwdModal = document.getElementById('pwdModal');
    const openPwdBtn = document.getElementById('openPasswordBtn');
    const closePwdBtn = document.getElementById('closePasswordBtn');
    const passwordForm = document.getElementById('passwordForm');

    // 1. Handle Login
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Here you would normally validate with a server
        loginScreen.style.opacity = '0';
        setTimeout(() => {
            loginScreen.classList.add('hidden');
        }, 500);
    });

    // 2. Handle Logout
    logoutBtn.addEventListener('click', () => {
        loginScreen.classList.remove('hidden');
        setTimeout(() => {
            loginScreen.style.opacity = '1';
        }, 10);
    });

    // 3. Handle Password Modal
    openPwdBtn.addEventListener('click', () => {
        pwdModal.classList.remove('hidden');
    });

    closePwdBtn.addEventListener('click', () => {
        pwdModal.classList.add('hidden');
    });

    // Close modal when clicking background
    pwdModal.addEventListener('click', (e) => {
        if (e.target === pwdModal) pwdModal.classList.add('hidden');
    });

    // 4. Handle Password Update
    passwordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Password updated successfully!');
        pwdModal.classList.add('hidden');
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const loginScreen = document.getElementById('loginScreen');

    // 1. Handle Login Transition
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Visual fade out
        loginScreen.style.opacity = '0';
        setTimeout(() => {
            loginScreen.classList.add('hidden');
        }, 500);
    });
});

// 2. Handle Logout
function handleLogout() {
    const loginScreen = document.getElementById('loginScreen');
    loginScreen.classList.remove('hidden');
    setTimeout(() => {
        loginScreen.style.opacity = '1';
    }, 10);
}

// 3. Toggle Modals
function toggleModal(id) {
    const modal = document.getElementById(id);
    modal.classList.toggle('hidden');
}
document.addEventListener('DOMContentLoaded', () => {
    const logoutBtn = document.getElementById('logoutBtn');

    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            // 1. Confirm with the user
            const confirmLogout = confirm("Are you sure you want to logout?");
            
            if (confirmLogout) {
                // 2. Clear session data
                localStorage.removeItem('isLoggedIn');
                sessionStorage.clear();

                // 3. Redirect to your specific login page
                window.location.href = "deanlogin.html";
            }
        });
    }
});
