<?php
include('db_connection.php');
// Make sure your db connection ($pdo) is included here

if (isset($_POST['submit_enrollment'])) {
    try {
        // 1. Generate the default hashed password
        $raw_password = "User123"; // You can tell students this is their default password
        $hashed_password = password_hash($raw_password, PASSWORD_DEFAULT);

        // 2. Prepare the INSERT query (Added 'password' and 'status' columns)
        $sql = "INSERT INTO students (
                    first_name, middle_name, last_name, gender, contact_number, email, 
                    parent_name, relationship_to_student, parent_email, emergency_contact,
                    date_of_birth, age, ethnicity, street_address, municipality, province, region, zipcode,
                    dialect, religion, password, status
                ) VALUES (
                    :first_name, :middle_name, :last_name, :gender, :contact_number, :email,
                    :parent_name, :relationship, :parent_email, :emergency_contact,
                    :dob, :age, :ethnicity, :street, :municipality, :province, :region, :zipcode,
                    :dialect, :religion, :password, :status
                )";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':first_name'       => $_POST['fname'],
            ':middle_name'      => $_POST['mname'] ?? null,
            ':last_name'        => $_POST['lname'],
            ':gender'           => $_POST['gender'] ?? null,
            ':contact_number'   => $_POST['phonenum'],
            ':email'            => $_POST['Ename'] ?? null,
            ':parent_name'      => $_POST['PGname'],
            ':relationship'     => $_POST['RSinfo'],
            ':parent_email'     => $_POST['PGEname'] ?? null,
            ':emergency_contact'=> $_POST['Enumber'],
            ':dob'              => $_POST['Birthdate'],
            ':age'              => $_POST['age'] ?? null,
            ':ethnicity'        => $_POST['Ethnicity'] ?? null,
            ':street'           => $_POST['street_address'] ?? null,
            ':municipality'     => $_POST['municipality'] ?? null,
            ':province'         => $_POST['province'] ?? null,
            ':region'           => $_POST['region'] ?? null,
            ':zipcode'          => $_POST['zipcode'] ?? null,
            ':dialect'          => $_POST['dialect'] ?? null,
            ':religion'         => $_POST['religion'] ?? null,
            ':password'         => $hashed_password, // Saved hashed password
            ':status'           => 'new'             // Default status
        ]);

        // 3. Get the auto-assigned student_id
        $student_id = $pdo->lastInsertId();

        // 4. Display success message with Login Link
        echo "<div style='text-align:center; padding: 50px; font-family: Arial;'>";
        echo "<h2 style='color: green;'>Enrollment Successful!</h2>";
        echo "<p>Your assigned Student ID is: <strong>$student_id</strong></p>";
        echo "<p>Your temporary password is: <strong>$raw_password</strong></p>";
        echo "<p style='color: red;'>Please save these credentials before proceeding.</p>";
        echo "<br>";
        echo "<a href='../studensubjectload/login.html' style='padding: 10px 20px; background: blue; color: white; text-decoration: none; border-radius: 5px;'>Click here to Login</a>";
        echo "</div>";

    } catch (PDOException $e) {
        die("Error inserting student: " . $e->getMessage());
    }
}
?>
