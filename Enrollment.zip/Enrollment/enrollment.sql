-- 1. Wipe the old database entirely
DROP DATABASE IF EXISTS enrollment_db;
CREATE DATABASE enrollment_db;
USE enrollment_db;

-- 2. Create Students Table (Matches your HTML exactly)
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    gender VARCHAR(20),
    contact_number VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    date_of_birth DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create Courses Table
CREATE TABLE courses (
    course_code VARCHAR(50) PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL
);

-- 4. Create Enrollments Table
CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_code VARCHAR(50) NOT NULL,
    school_year VARCHAR(20),
    semester VARCHAR(20),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_code) REFERENCES courses(course_code)
);

-- 5. Add Courses (Crucial for your dropdown to work)
INSERT INTO courses (course_code, course_name) VALUES 
('BSIT', 'Bachelor of Science in Information Technology'),
('BSCE', 'Bachelor of Science in Civil Engineering');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('COURSE', 'DESC', 'MAJOR', 'SY', 'SEM');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSCE', 'Bachelor of Science in Civil Engineering', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSCS', 'Bachelor of Science in Computer Science', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSCA', 'Bachelor of Science in Customs Administration', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSSW', 'Bachelor of Science in Social Work', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor of Arts', 'Social Science', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor of Arts', 'Filipino', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor of Arts', 'Economics', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor of Arts', 'English', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor of Arts', 'Mass Communication', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSOA', 'Bachelor of Science in Office Administration', 'Office Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSOA', 'Bachelor of Science in Office Administration', 'Computer Education', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AOA', 'Associate in Office Administration', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSCR', 'Bachelor of Science in Criminology', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSA', 'Bachelor of Science in Accountancy', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'Filipino', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSED', 'Bachelor of Secondary Education', 'Math', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSED', 'Bachelor of Secondary Education', 'Science', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSED', 'Bachelor of Secondary Education', 'Filipino', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSED', 'Bachelor of Secondary Education', 'English', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('MA', 'Master of Arts', 'English', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('MA', 'Master of Arts', 'Guidance and Counseling', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('MA', 'Master of Arts', 'Educational Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'Math', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'English', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'General Science', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor or Arts', 'Psychology', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSIT', 'Bachelor of Science in Information Technology', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Management Accounting', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSIM', 'Bachelor of Science in Information Management', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('ACT', 'Associates in Computer Technology', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('CT', 'Computer System and Network Specialist', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('MT', 'Medical Transcriptionist', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('CC', 'Contact Center', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'Generalist', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('CHS', 'COMPUTER HARDWARE SERVICING NCII', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Financial Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Marketing Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('AB', 'Bachelor or Arts', 'Legal Studies', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('ETEEAP', 'BSCR-ETEEAP', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSEN', 'Bachelor of Science in Entrepreneurship', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSGE', 'Bachelor of Science in Geodetic Engineering', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Business Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSES', 'Bachelor of Science in Environmental Science', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSMATH', 'Bachelor of Science in Mathematics', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSED', 'Bachelor of Secondary Education', 'Mapeh', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSED', 'Bachelor of Secondary Education', 'Physical Science', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Operation Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BPE', 'Bachelor of Physical Education', 'School Physical Education', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('WINSW', 'Bachelor of Science in Social Work', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BTLED', 'Bachelor of Technology and Livelihood Education', 'Home Economics', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSC', 'Bachelor of Science in Commerce', 'Business Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSC', 'Bachelor of Science in Commerce', 'Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSC', 'Bachelor of Science in Commerce', 'Marketing', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('ACS', 'Associate in Computer Science', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('PSP', 'POST SECONDARY PROGRAM', 'CHS NC2 & PROGRAMMING NC4', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('JSC', 'Junior Secretarial Course', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('CSC', 'Computer Secretarial Course', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'Pre-School Education', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSAT', 'Bachelor of Science in Accounting Technology', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('PSP', 'POST SECONDARY PROGRAM', 'BOOKKEEPING NC3', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Business Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Financial Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Marketing Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSBA', 'Bachelor of Science in Business Administration', 'Operation Management', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('SHS', 'Senior High School', 'ABM', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('SHS', 'Senior High School', 'HUMSS', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('SHS', 'Senior High School', 'STEM', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('SHS', 'Senior High School', 'GAS', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BPED', 'Bachelor of Physical Education', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BLIS', 'Bachelor of Library and Information Science', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSOA', 'Bachelor of Science in Office Administration', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSMA', 'Bachelor of Science in Management Accounting', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BECED', 'Bachelor of Early Childhood Education', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSIA', 'Bachelor of Science in Internal Auditing', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSAIS', 'Bachelor of Science in Accounting Information System', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', 'Early Childhood Education', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BSC', 'Bachelor of Science in Commerce', 'Banking and Finance', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('BEED', 'Bachelor of Elementary Education', '', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('GRADER', 'BASIC EDUCATION', 'GRADE1', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('GRADER', 'BASIC EDUCATION', 'GRADE2', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('GRADER', 'BASIC EDUCATION', 'GRADE3', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('GRADER', 'BASIC EDUCATION', 'GRADE4', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('GRADER', 'BASIC EDUCATION', 'GRADE5', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('GRADER', 'BASIC EDUCATION', 'GRADE6', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('JHIGH', 'JUNIOR HIGH', 'GRADE7', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('JHIGH', 'JUNIOR HIGH', 'GRADE8', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('JHIGH', 'JUNIOR HIGH', 'GRADE9', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('JHIGH', 'JUNIOR HIGH', 'GRADE10', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('PREP', 'PREPARATORY', 'K1', '', '');

INSERT INTO courses
   (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`)
VALUES
   ('PREP', 'PREPARATORY', 'K2', '', '');

