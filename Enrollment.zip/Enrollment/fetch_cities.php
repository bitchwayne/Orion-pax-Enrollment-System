<?php
include 'db_connection.php';
header('Content-Type: application/json');

try {
    // Determine which type of data is requested
    $type = $_GET['type'] ?? '';
    $id = $_GET['id'] ?? '';

    switch($type) {
        case 'regions':
            $stmt = $pdo->query("SELECT DISTINCT REGION FROM cities ORDER BY REGION ASC");
            $data = $stmt->fetchAll(PDO::FETCH_COLUMN);
            break;

        case 'provinces':
            $stmt = $pdo->prepare("SELECT DISTINCT PROVINCE FROM cities WHERE REGION = ? ORDER BY PROVINCE ASC");
            $stmt->execute([$id]);
            $data = $stmt->fetchAll(PDO::FETCH_COLUMN);
            break;

        case 'municipalities':
            $stmt = $pdo->prepare("SELECT DISTINCT CITIES_MUNICIPALITIES FROM cities WHERE PROVINCE = ? ORDER BY CITIES_MUNICIPALITIES ASC");
            $stmt->execute([$id]);
            $data = $stmt->fetchAll(PDO::FETCH_COLUMN);
            break;

        case 'zipcodes':
            $stmt = $pdo->prepare("SELECT DISTINCT ZIPCODE FROM cities WHERE CITIES_MUNICIPALITIES = ? ORDER BY ZIPCODE ASC");
            $stmt->execute([$id]);
            $data = $stmt->fetchAll(PDO::FETCH_COLUMN);
            break;

        default:
            $data = [];
    }

    echo json_encode($data);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}