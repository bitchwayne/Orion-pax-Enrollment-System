<?php
require 'enrollment_db';

// Handle Province request
if (isset($_POST['region'])) {
    $region = $_POST['region'];
    $query = "SELECT DISTINCT PROVINCE FROM cities WHERE REGION = '$region' ORDER BY PROVINCE ASC";
    $result = $conn->query($query);
    
    echo '<option value="">Select Province</option>';
    while($row = $result->fetch_assoc()) {
        echo '<option value="'.$row['PROVINCE'].'">'.$row['PROVINCE'].'</option>';
    }
}

// Handle City/Zipcode request
if (isset($_POST['province'])) {
    $province = $_POST['province'];
    $query = "SELECT DISTINCT CITIES_MUNICIPALITIES, ZIPCODE FROM cities WHERE PROVINCE = '$province' ORDER BY CITIES_MUNICIPALITIES ASC";
    $result = $conn->query($query);
    
    echo '<option value="">Select City</option>';
    while($row = $result->fetch_assoc()) {
        echo '<option value="'.$row['CITIES_MUNICIPALITIES'].'" data-zip="'.$row['ZIPCODE'].'">'.$row['CITIES_MUNICIPALITIES'].'</option>';
    }
}
?>
