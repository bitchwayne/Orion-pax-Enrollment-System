const steps = document.querySelectorAll(".form-step");
const indicators = document.querySelectorAll(".step-indicator");
const nextBtns = document.querySelectorAll(".next-btn");
const prevBtns = document.querySelectorAll(".prev-btn");

// Navigation logic for Next/Back
nextBtns.forEach((btn, i) => {
    btn.onclick = () => {
        steps[i].classList.remove("active");
        steps[i+1].classList.add("active");
        if(indicators[i+1]) indicators[i+1].classList.add("active");
    };
});

prevBtns.forEach((btn, i) => {
    btn.onclick = () => {
        steps[i+1].classList.remove("active");
        steps[i].classList.add("active");
        if(indicators[i+1]) indicators[i+1].classList.remove("active");
    };
});

// Auto-Increment ID Generation
function getNextID() {
    let lastID = localStorage.getItem("lastID") || 2026000;
    let nextID = parseInt(lastID) + 1;
    localStorage.setItem("lastID", nextID);
    return "STU-" + nextID;
}

// Logic for the Final Step (Subject Load)
document.getElementById('enrollmentWizard').onsubmit = function(e) {
    e.preventDefault();

    // 1. Generate ID & Capture Data
    document.getElementById('displayID').innerText = getNextID();
    document.getElementById('displayName').innerText = document.querySelector('[name="fname"]').value + " " + document.querySelector('[name="lname"]').value;
    
    const courseSelect = document.getElementById('courseSelect');
    document.getElementById('displayCourse').innerText = courseSelect.options[courseSelect.selectedIndex].text;

    // 2. Load Subjects
    const table = document.getElementById('subjectTableBody');
    table.innerHTML = `
        <tr style="border-bottom: 1px solid #eee;"><td style="padding:10px">IT101</td><td>Computing Fundamentals</td><td align="center">3</td></tr>
        <tr style="border-bottom: 1px solid #eee;"><td style="padding:10px">PROG11</td><td>Intro to Programming</td><td align="center">3</td></tr>
        <tr style="border-bottom: 1px solid #eee;"><td style="padding:10px">GE105</td><td>Purposive Communication</td><td align="center">3</td></tr>
    `;

    // 3. Show Subject Load UI
    steps.forEach(s => s.classList.remove("active"));
    document.getElementById('subjectLoadStep').classList.add("active");
};

// Age Calculator
function calculateAge() {
    const birthDate = new Date(document.getElementById('birthdate').value);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    if (today.getMonth() < birthDate.getMonth() || (today.getMonth() === birthDate.getMonth() && today.getDate() < birthDate.getDate())) age--;
    document.getElementById('age').value = age;
}
