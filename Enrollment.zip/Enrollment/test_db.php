<?php
include 'db_connection.php';
echo "Connected successfully to the database!";
?>
