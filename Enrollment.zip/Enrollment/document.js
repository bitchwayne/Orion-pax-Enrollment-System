

document.addEventListener('DOMContentLoaded', () => {
    // Fetch regions
    fetch('get_regions.php')
    .then(res => res.json())
    .then(regions => {
        const regionSelect = document.getElementById('regionSelect');
        regions.forEach(r => {
            let opt = document.createElement('option');
            opt.value = r.region_id;
            opt.textContent = r.region_name;
            regionSelect.appendChild(opt);
        });
    });

    // Region → Province
    document.getElementById('regionSelect').addEventListener('change', function() {
        const region_id = this.value;
        fetch('get_provinces.php?region_id=' + region_id)
        .then(res => res.json())
        .then(provinces => {
            const provinceSelect = document.getElementById('provinceSelect');
            provinceSelect.innerHTML = '<option value="">Select Province</option>';
            provinces.forEach(p => {
                let opt = document.createElement('option');
                opt.value = p.province_id;
                opt.textContent = p.province_name;
                provinceSelect.appendChild(opt);
            });
            document.getElementById('municipalitySelect').innerHTML = '<option value="">Select Municipality</option>';
            document.getElementById('zipcodeSelect').innerHTML = '<option value="">Select Zipcode</option>';
        });
    });

    // Province → Municipality/City
    document.getElementById('provinceSelect').addEventListener('change', function() {
        const province_id = this.value;
        fetch('get_municipalities.php?province_id=' + province_id)
        .then(res => res.json())
        .then(municipalities => {
            const municipalitySelect = document.getElementById('municipalitySelect');
            municipalitySelect.innerHTML = '<option value="">Select Municipality</option>';
            municipalities.forEach(m => {
                let opt = document.createElement('option');
                opt.value = m.municipality_id;
                opt.textContent = m.municipality_name;
                municipalitySelect.appendChild(opt);
            });
            document.getElementById('zipcodeSelect').innerHTML = '<option value="">Select Zipcode</option>';
        });
    });

    // Municipality → Zipcode
    document.getElementById('municipalitySelect').addEventListener('change', function() {
        const municipality_id = this.value;
        fetch('get_zipcodes.php?municipality_id=' + municipality_id)
        .then(res => res.json())
        .then(zipcodes => {
            const zipcodeSelect = document.getElementById('zipcodeSelect');
            zipcodeSelect.innerHTML = '<option value="">Select Zipcode</option>';
            zipcodes.forEach(z => {
                let opt = document.createElement('option');
                opt.value = z.zipcode_code;
                opt.textContent = z.zipcode_code;
                zipcodeSelect.appendChild(opt);
            });
        });
    });
});