<?php
include 'db_connection.php';

// Get the student ID from the URL (e.g., view_schedule.php?id=1)
$student_id = $_GET['id'] ?? 0;

$sql = "SELECT s.first_name, s.last_name, e.course_code, ss.subject_code, 
               c.subject_name, ss.day_of_week, ss.start_time, ss.end_time, ss.room_number
        FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        JOIN student_subjects ss ON e.enrollment_id = ss.enrollment_id
        JOIN curriculum c ON ss.subject_code = c.subject_code
        WHERE s.student_id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$student_id]);
$schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Schedule</title>
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Class Schedule for <?php echo $schedule[0]['first_name'] . " " . $schedule[0]['last_name']; ?></h2>
    <p>Course: <?php echo $schedule[0]['course_code']; ?></p>

    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Subject Name</th>
                <th>Day</th>
                <th>Time</th>
                <th>Room</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($schedule as $row): ?>
            <tr>
                <td><?php echo $row['subject_code']; ?></td>
                <td><?php echo $row['subject_name']; ?></td>
                <td><?php echo $row['day_of_week']; ?></td>
                <td><?php echo $row['start_time'] . " - " . $row['end_time']; ?></td>
                <td><?php echo $row['room_number']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
