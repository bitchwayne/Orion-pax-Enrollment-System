<?php
// other_options.php
include 'db_connection.php';

header('Content-Type: application/json');

$type = $_GET['type'] ?? '';

try {
    if ($type === 'dialects') {
        $stmt = $pdo->query("SELECT DISTINCT dialects FROM dialects ORDER BY dialects ASC");
        $options = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } elseif ($type === 'religions') {
        $stmt = $pdo->query("SELECT DISTINCT religion FROM religions ORDER BY religion ASC");
        $options = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } elseif ($type === 'ethnicity') {
        $stmt = $pdo->query("SELECT DISTINCT ethnicname FROM ethnicity ORDER BY ethnicname ASC");
        $options = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } else {
        $options = [];
    }

    echo json_encode($options);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>