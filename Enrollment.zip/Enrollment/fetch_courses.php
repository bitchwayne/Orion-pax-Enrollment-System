<?php
// Disable warnings/notices to avoid breaking JSON
error_reporting(E_ERROR | E_PARSE);

// Include PDO connection
include 'db_connection.php';

// Set JSON header
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT COURSE, MAJOR FROM courses");
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($courses);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}   